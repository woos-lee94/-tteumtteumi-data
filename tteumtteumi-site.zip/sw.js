/* 틈틈이 서비스 워커
   - 앱 화면과 카드 데이터는 기기에 저장해 두고(오프라인에서도 열림)
   - 뉴스(data/news.json)는 항상 새로 받아 오되, 인터넷이 없으면 저장본을 보여 줘요.
   - 파일을 고쳐 다시 올릴 때는 VERSION 숫자를 올려 주세요. */
const VERSION = 'tteum-v0.2.3';
const FONT_CACHE = 'tteum-fonts-v1';
const SHELL = [
  './', './index.html', './styles.css', './app.js', './manifest.webmanifest',
  './icons/icon-180.png', './icons/icon-192.png', './icons/favicon-32.png',
  './data/news.json', './data/reading.json',
  './data/daily/proverb.json', './data/daily/idiom.json', './data/daily/trivia.json',
  './data/daily/origin.json', './data/daily/word.json',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('tteum-v') && k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function networkFirst(req, fallbackUrl) {
  const cache = await caches.open(VERSION);
  try {
    const res = await fetch(req);
    if (res && res.ok) cache.put(req, res.clone());
    return res;
  } catch (err) {
    const hit = (await cache.match(req, { ignoreSearch: true })) || (fallbackUrl ? await cache.match(fallbackUrl) : null);
    if (hit) return hit;
    throw err;
  }
}

async function staleWhileRevalidate(req) {
  const cache = await caches.open(VERSION);
  const hit = await cache.match(req);
  const net = fetch(req).then((res) => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
  return hit || (await net) || Response.error();
}

async function cacheFirst(req, name) {
  const cache = await caches.open(name);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
  return res;
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === self.location.origin) {
    if (req.mode === 'navigate') { e.respondWith(networkFirst(req, './index.html')); return; }
    if (/\/data\/(news|reading)\.json$/.test(url.pathname)) { e.respondWith(networkFirst(req)); return; }
    e.respondWith(staleWhileRevalidate(req));
    return;
  }
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    e.respondWith(cacheFirst(req, FONT_CACHE));
  }
  // 날씨·위키백과 같은 바깥 정보는 늘 새로 받아요(앱이 따로 짧게 저장).
});
