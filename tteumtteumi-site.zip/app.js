/* 틈틈이 · 출퇴근길 한 장 (시험판)
   - 뉴스: data/news.json
   - 오늘의 한 장: data/daily/*.json 을 날짜 알고리즘으로 하루 한 장씩 뽑아요.
   - 기록(보관함·좋아요·형광펜)은 이 기기의 브라우저 저장소(localStorage)에 남아요. */
(() => {
  'use strict';

  const VERSION = '0.2.3';
  const PREVIEW = !!window.__PREVIEW__;

  // ---------------------------------------------------------------- 분야
  // subs: 분야 안의 세부 종류(칩 순서). reading: 날마다 바뀌는 뉴스가 아니라 오래 두고 읽는 글. tabs: 세부 종류를 탭으로.
  const NEWS_CATS = [
    { key: 'politics', label: '정치', desc: '대통령실·정당·선거·외교안보', color: '#3558D4', subs: ['대통령실', '정당', '선거', '외교·안보', '정부'] },
    { key: 'assembly', label: '국회', desc: '국정감사·법안·청문회·예산', color: '#5B47C8', subs: ['국정감사', '법안', '본회의', '청문회', '예산', '상임위'] },
    { key: 'policy', label: '생활정책', desc: '달라지는 제도와 지원', color: '#11897B', subs: ['교통', '복지', '세금·금융', '주거', '일자리', '교육·보육', '건강'] },
    { key: 'society', label: '사회·사건', desc: '사건사고·재판·교육·노동·환경', color: '#C8662A', subs: ['사건사고', '재판', '제도', '교육', '노동', '환경·기후', '보건', '안전'] },
    { key: 'economy', label: '경제', desc: '금리·물가·부동산·산업', color: '#2E8B4A', subs: ['금리·환율', '물가', '부동산', '산업·기업', '고용', '무역', '성장'] },
    { key: 'stock', label: '주식', desc: '국내외 증시·업종·공모주', color: '#D0453A', subs: ['국내 증시', '해외 증시', '업종·종목', '공모주', 'ETF·배당', '투자 제도'], note: '시장 소식을 쉽게 풀어 쓴 글이에요. 특정 종목을 사거나 팔라는 뜻이 아니고, 투자 판단과 책임은 본인에게 있어요.' },
    { key: 'world', label: '국제', desc: '세계 뉴스와 외교', color: '#2386B8', subs: ['미국', '중국', '일본', '유럽', '중동', '러시아·우크라이나', '아시아', '중남미·아프리카', '국제기구'] },
    { key: 'tech', label: 'IT·과학', desc: 'AI·반도체·모바일·우주', color: '#8A45C9', subs: ['AI', '반도체', '모바일·가전', '로봇', '우주', '과학', '보안', '게임'] },
    { key: 'sports', label: '스포츠', desc: '야구·축구·골프·국제대회', color: '#E07B24', subs: ['야구', '축구', '농구·배구', '골프', '국제대회', 'e스포츠', '기타 종목'] },
    { key: 'entertainment', label: '연예', desc: 'K팝·드라마·예능·배우', color: '#D1407A', subs: ['K팝', '드라마', '예능', '영화·배우', '시상식'] },
    { key: 'culture', label: '문화', desc: '영화·OTT·책·공연·전시', color: '#946A3A', subs: ['영화', 'OTT', '책', '공연', '전시', '전통문화'] },
    { key: 'fashion', label: '패션', desc: '트렌드·브랜드·패션위크·뷰티', color: '#7C8A18', subs: ['트렌드', '브랜드·업계', '패션위크', '뷰티', '스타일'] },
    { key: 'events', label: '행사', desc: '전국 축제·공연·박람회·대회', color: '#C29A0A', subs: ['축제', '공연·콘서트', '전시·박람회', '스포츠 대회', '기념 행사'] },
    { key: 'history', label: '역사', desc: '한국사·현대사·우리 동네 역사', color: '#7A5A43', subs: ['한국사', '현대사', '우리 동네 역사'], reading: true, tabs: true, whyLabel: '오늘 되새길 점' },
    { key: 'living', label: '생활', desc: '세탁·청소 살림 요령', color: '#2F8F9D', subs: ['세탁', '청소'], reading: true, whyLabel: '이것만 기억해요' },
  ];
  const DAILY_CATS = [
    { key: 'proverb', label: '속담', title: '오늘의 속담', color: '#2F7D5B' },
    { key: 'idiom', label: '사자성어', title: '오늘의 사자성어', color: '#B83A2E' },
    { key: 'trivia', label: '상식', title: '오늘의 상식', color: '#2D62D0' },
    { key: 'origin', label: '유래', title: '알고 보면 유래', color: '#A56A1B' },
    { key: 'word', label: '우리말', title: '오늘의 우리말', color: '#0E8A7D' },
  ];
  const FORTUNE_TAB = { key: 'fortune', label: '운세', title: '오늘의 운세', color: '#7650CF' };
  const LOCS = [
    { name: '서울 종로', lat: 37.5709, lon: 127.0019 },
    { name: '서울 강남', lat: 37.4979, lon: 127.0276 },
    { name: '서울 여의도', lat: 37.5219, lon: 126.9245 },
    { name: '인천', lat: 37.4563, lon: 126.7052 },
    { name: '수원', lat: 37.2636, lon: 127.0286 },
    { name: '고양', lat: 37.6584, lon: 126.832 },
    { name: '대전', lat: 36.3504, lon: 127.3845 },
    { name: '대구', lat: 35.8714, lon: 128.6014 },
    { name: '광주', lat: 35.1595, lon: 126.8526 },
    { name: '부산', lat: 35.1796, lon: 129.0756 },
  ];
  const newsCat = (k) => NEWS_CATS.find((c) => c.key === k);
  const dailyCat = (k) => DAILY_CATS.find((c) => c.key === k) || (k === 'fortune' ? FORTUNE_TAB : null);

  // ---------------------------------------------------------------- 작은 도구
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const safeUrl = (u) => (/^https?:\/\//i.test(String(u || '')) ? String(u) : ''); // 데이터 속 링크는 http(s)만
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const reduceMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function hashStr(s) { let h = 2166136261 >>> 0; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function mulberry32(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function weightedPick(arr, weights, rng) { const total = weights.reduce((s, w) => s + w, 0); let x = rng() * total; for (let i = 0; i < arr.length; i++) { x -= weights[i]; if (x < 0) return arr[i]; } return arr[arr.length - 1]; }
  const pickFrom = (arr, rng) => arr[Math.floor(rng() * arr.length) % arr.length];

  // ---------------------------------------------------------------- 아이콘 (선 아이콘)
  const IC = {
    home: '<path d="M4 11.5 12 4.5l8 7"/><path d="M6.5 10v9.5h11V10"/><path d="M10 19.5v-5h4v5"/>',
    page: '<rect x="4.5" y="4.5" width="15" height="16" rx="2.5"/><path d="M4.5 9.5h15"/><path d="M9 2.8v3.4M15 2.8v3.4"/><path d="M8.5 14h7M8.5 17h4.5"/>',
    archive: '<rect x="3.5" y="4.5" width="17" height="4.5" rx="1.4"/><path d="M5 9v10.5h14V9"/><path d="M10 13h4"/>',
    heart: '<path d="M12 19.5s-7.5-4.6-7.5-10A4.2 4.2 0 0 1 12 7a4.2 4.2 0 0 1 7.5 2.5c0 5.4-7.5 10-7.5 10z"/>',
    'heart-fill': '<path class="fill" d="M12 19.5s-7.5-4.6-7.5-10A4.2 4.2 0 0 1 12 7a4.2 4.2 0 0 1 7.5 2.5c0 5.4-7.5 10-7.5 10z"/>',
    marker: '<path d="m14.5 4.5 5 5-8.2 8.2H6.3v-5z"/><path d="m12.5 6.5 5 5"/><path d="M4 20.5h8"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    'chev-l': '<path d="m15 5-7 7 7 7"/>',
    'chev-r': '<path d="m9 5 7 7-7 7"/>',
    'chev-d': '<path d="m6 9 6 6 6-6"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
    ext: '<path d="M14 4h6v6M20 4l-8.5 8.5"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V5.5a1 1 0 0 0-1-1h-9a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h3"/>',
    refresh: '<path d="M19.5 11.5a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.5 4.5v5h-5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    umbrella: '<path d="M3.5 12a8.5 8.5 0 0 1 17 0z"/><path d="M12 12v6.2a2 2 0 0 0 4 0"/><path d="M12 3.5v-1"/>',
    bulb: '<path d="M9 17.5h6M10 20.5h4"/><path d="M12 3.5a5.5 5.5 0 0 0-3.2 10c.7.5 1.2 1.3 1.2 2.2v.3h4v-.3c0-.9.5-1.7 1.2-2.2A5.5 5.5 0 0 0 12 3.5z"/>',
    pin: '<path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
    share: '<path d="M12 3.5v11"/><path d="m8 7.5 4-4 4 4"/><path d="M6 11.5v7.5h12v-7.5"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2M12 19.2v2M2.8 12h2M19.2 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4"/>',
    moon: '<path d="M19.5 14.2A7.8 7.8 0 1 1 9.8 4.5a6.2 6.2 0 0 0 9.7 9.7z"/>',
    cloud: '<path d="M7.2 18.5h9.9a4 4 0 0 0 .5-8 6 6 0 0 0-11.4 1.4 3.3 3.3 0 0 0 1 6.6z"/>',
    partly: '<path d="M8.5 3v1.4M3.4 8.1h1.4M4.9 4.5l1 1M12.1 4.5l-1 1"/><path d="M5.7 11a3.4 3.4 0 1 1 6-3"/><path d="M9.8 20h7.9a3.4 3.4 0 0 0 .4-6.8 5 5 0 0 0-9.6 1.2 2.8 2.8 0 0 0 1.3 5.6z"/>',
    rain: '<path d="M7.2 15h9.9a4 4 0 0 0 .5-8 6 6 0 0 0-11.4 1.4A3.3 3.3 0 0 0 7.2 15z"/><path d="m8.5 18-1 2.5M12.5 18l-1 2.5M16.5 18l-1 2.5"/>',
    snow: '<path d="M7.2 15h9.9a4 4 0 0 0 .5-8 6 6 0 0 0-11.4 1.4A3.3 3.3 0 0 0 7.2 15z"/><path d="M8 18.5h.01M12 18.5h.01M16 18.5h.01M10 21h.01M14 21h.01"/>',
    fog: '<path d="M4 9.5h16M3 13.5h18M5 17.5h14"/>',
    storm: '<path d="M7.2 15h9.9a4 4 0 0 0 .5-8 6 6 0 0 0-11.4 1.4A3.3 3.3 0 0 0 7.2 15z"/><path d="m13 15.5-2.5 3.5h3.5L11.5 22"/>',
    'cat-politics': '<path d="M4 20h16M6 20v-7.5M10 20v-7.5M14 20v-7.5M18 20v-7.5M3.5 12.5h17"/><path d="M12 4 20 9.5H4z"/>',
    'cat-policy': '<path d="M7 3.5h7l4 4v13H7z"/><path d="M14 3.5v4h4"/><path d="m9.5 14 2 2 3.5-4"/>',
    'cat-society': '<circle cx="9" cy="8.5" r="3"/><path d="M3.5 19.5c.8-3.1 3-4.9 5.5-4.9s4.7 1.8 5.5 4.9"/><circle cx="17" cy="9.5" r="2.3"/><path d="M15.8 14.7c2.3.2 4 1.8 4.7 4.8"/>',
    'cat-economy': '<path d="M4 19.5h16"/><path d="m5 15.5 4-4 3 3 6.5-6.5"/><path d="M15 8h3.5v3.5"/>',
    'cat-world': '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.4 2.6 3.6 5.4 3.6 8.5s-1.2 5.9-3.6 8.5c-2.4-2.6-3.6-5.4-3.6-8.5S9.6 6.1 12 3.5z"/>',
    'cat-tech': '<rect x="7" y="7" width="10" height="10" rx="2"/><path d="M10 3.5V7M14 3.5V7M10 17v3.5M14 17v3.5M3.5 10H7M3.5 14H7M17 10h3.5M17 14h3.5"/>',
    'cat-sports': '<circle cx="12" cy="12" r="8.5"/><path d="m12 8 3.5 2.6-1.3 4.1H9.8l-1.3-4.1z"/><path d="M12 3.5V8M15.5 10.6l4.3-1.3M14.2 14.7l2.6 3.7M9.8 14.7l-2.6 3.7M8.5 10.6 4.2 9.3"/>',
    'cat-entertainment': '<rect x="9" y="3.5" width="6" height="10.5" rx="3"/><path d="M5.8 11a6.2 6.2 0 0 0 12.4 0M12 17.2v3.3M8.8 20.5h6.4"/>',
    'cat-culture': '<path d="M3.5 7h17v3a2 2 0 0 0 0 4v3h-17v-3a2 2 0 0 0 0-4z"/><path d="M14.5 7.5v1.6M14.5 11.2v1.6M14.5 14.9v1.6"/>',
    'cat-assembly': '<path d="M3.5 20h17M6 20v-6M10 20v-6M14 20v-6M18 20v-6M4.5 14h15"/><path d="M6 14a6 6 0 0 1 12 0"/><path d="M12 5v3"/>',
    'cat-stock': '<path d="M7 3.5v17M12 6v13M17 4.5v15"/><rect x="5.2" y="8" width="3.6" height="7.5" rx="0.8"/><rect x="10.2" y="10.5" width="3.6" height="5" rx="0.8"/><rect x="15.2" y="7" width="3.6" height="8" rx="0.8"/>',
    'cat-fashion': '<path d="M12 8.2a1.9 1.9 0 1 1 1.9-1.9c0 1.1-1.9 1.4-1.9 2.8V9.8"/><path d="M12 9.8 3.6 15.6a1 1 0 0 0 .6 1.9h15.6a1 1 0 0 0 .6-1.9z"/>',
    'cat-events': '<rect x="4" y="5" width="16" height="15.5" rx="2.5"/><path d="M4 9.5h16M8.5 3v4M15.5 3v4"/><path d="m12 11.6 1.1 2.2 2.4.35-1.75 1.7.4 2.4L12 17.1l-2.15 1.15.4-2.4-1.75-1.7 2.4-.35z"/>',
    'cat-history': '<path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v14.5H7.5A2.5 2.5 0 0 0 5 20z"/><path d="M5 20a2.5 2.5 0 0 1 2.5-2.5H19V21H7.5A2.5 2.5 0 0 1 5 20z"/><path d="M9 7.5h6M9 10.5h4"/>',
    'cat-living': '<path d="M9 8.5h5.5l1 3v8.3a1.2 1.2 0 0 1-1.2 1.2H9.2A1.2 1.2 0 0 1 8 19.8v-8.3z"/><path d="M10 8.5v-3h3.6l2.4 1.6"/><path d="M18.5 4.5h.01M20 7h.01M18.5 9.5h.01"/>',
  };
  const icon = (name, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${IC[name] || ''}</svg>`;

  // ---------------------------------------------------------------- 날짜 (한국 시간 기준)
  const DAY = 86400000;
  const DOW = ['일', '월', '화', '수', '목', '금', '토'];
  const kstFmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
  function nowKST() {
    const p = {};
    for (const x of kstFmt.formatToParts(new Date())) p[x.type] = x.value;
    return { key: `${p.year}-${p.month}-${p.day}`, hour: Number(p.hour) % 24, minute: Number(p.minute) };
  }
  const toUTC = (k) => { const [y, m, d] = k.split('-').map(Number); return Date.UTC(y, m - 1, d); };
  const fromUTC = (t) => new Date(t).toISOString().slice(0, 10);
  const addDays = (k, n) => fromUTC(toUTC(k) + n * DAY);
  const diffDays = (a, b) => Math.round((toUTC(a) - toUTC(b)) / DAY);
  const dow = (k) => new Date(toUTC(k)).getUTCDay();
  const md = (k) => { const [, m, d] = k.split('-').map(Number); return { m, d }; };
  const dateLabel = (k) => { const { m, d } = md(k); return `${m}월 ${d}일`; };
  const dateDow = (k) => `${dateLabel(k)} (${DOW[dow(k)]})`;

  // 음력 (브라우저 내장 달력 사용)
  let lunarFmt = null;
  for (const cal of ['dangi', 'chinese']) {
    try {
      const f = new Intl.DateTimeFormat(`ko-KR-u-ca-${cal}`, { timeZone: 'UTC', year: 'numeric', month: 'numeric', day: 'numeric' });
      if (f.resolvedOptions().calendar === cal) { lunarFmt = f; break; }
    } catch (e) { /* 지원하지 않는 브라우저 */ }
  }
  function lunarAt(t) {
    if (!lunarFmt) return null;
    try {
      const p = {};
      for (const x of lunarFmt.formatToParts(new Date(t + DAY / 2))) p[x.type] = (p[x.type] || '') + x.value;
      const mRaw = p.month || '';
      const m = mRaw.replace(/[^0-9]/g, '');
      const d = (p.day || '').replace(/[^0-9]/g, '');
      if (!m || !d) return null;
      return { m, d, leap: /윤|bis|leap/i.test(mRaw), yearName: p.yearName || '' };
    } catch (e) { return null; }
  }
  const lunarOf = (k) => lunarAt(toUTC(k));

  // 일진(60갑자)
  const STEM_H = '甲乙丙丁戊己庚辛壬癸', STEM_K = '갑을병정무기경신임계';
  const BR_H = '子丑寅卯辰巳午未申酉戌亥', BR_K = '자축인묘진사오미신유술해';
  const ZODIAC = ['쥐', '소', '호랑이', '토끼', '용', '뱀', '말', '양', '원숭이', '닭', '개', '돼지'];
  const STEM_COLOR = ['푸른', '푸른', '붉은', '붉은', '누런', '누런', '하얀', '하얀', '검은', '검은'];
  const STEM_EL = ['목', '목', '화', '화', '토', '토', '금', '금', '수', '수'];
  const EL_INFO = {
    목: { name: '나무(木)', color: '초록', dir: '동쪽', nums: '3, 8' },
    화: { name: '불(火)', color: '빨강', dir: '남쪽', nums: '2, 7' },
    토: { name: '흙(土)', color: '노랑', dir: '가운데', nums: '5, 10' },
    금: { name: '쇠(金)', color: '흰색', dir: '서쪽', nums: '4, 9' },
    수: { name: '물(水)', color: '남색', dir: '북쪽', nums: '1, 6' },
  };
  function jdn(k) { const [y, m, d] = k.split('-').map(Number); const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3; return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4) - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045; }
  function ganji(k) { const i = (((jdn(k) + 49) % 60) + 60) % 60; return { i, s: i % 10, b: i % 12 }; }
  const ganjiK = (g) => STEM_K[g.s] + BR_K[g.b];
  const ganjiH = (g) => STEM_H[g.s] + BR_H[g.b];

  // 공휴일 (관공서의 공휴일에 관한 규정 기준, 대체공휴일 포함)
  const FIXED_HOL = [['01-01', '새해 첫날', false], ['03-01', '삼일절', true], ['05-05', '어린이날', true], ['06-06', '현충일', false], ['08-15', '광복절', true], ['10-03', '개천절', true], ['10-09', '한글날', true], ['12-25', '성탄절', true]];
  const holCache = {};
  function lunarToSolar(y, lm, ld, from, to) {
    for (let t = Date.UTC(y, from[0] - 1, from[1]); t <= Date.UTC(y, to[0] - 1, to[1]); t += DAY) {
      const L = lunarAt(t);
      if (L && !L.leap && L.m === String(lm) && L.d === String(ld)) return fromUTC(t);
    }
    return null;
  }
  function holidays(y) {
    if (holCache[y]) return holCache[y];
    const list = new Map();
    const count = new Map();
    const put = (k, name) => { if (!list.has(k)) list.set(k, name); count.set(k, (count.get(k) || 0) + 1); };
    const rules = [];
    for (const [mmdd, name, sub] of FIXED_HOL) { const k = `${y}-${mmdd}`; put(k, name); if (sub) rules.push({ days: [k], name, weekend: true }); }
    if (lunarFmt) {
      const seol = lunarToSolar(y, 1, 1, [1, 15], [2, 25]);
      if (seol) { const days = [addDays(seol, -1), seol, addDays(seol, 1)]; days.forEach((k) => put(k, k === seol ? '설날' : '설 연휴')); rules.push({ days, name: '설날', weekend: false }); }
      const buddha = lunarToSolar(y, 4, 8, [4, 10], [6, 5]);
      if (buddha) { put(buddha, '부처님오신날'); rules.push({ days: [buddha], name: '부처님오신날', weekend: true }); }
      const chu = lunarToSolar(y, 8, 15, [8, 25], [10, 10]);
      if (chu) { const days = [addDays(chu, -1), chu, addDays(chu, 1)]; days.forEach((k) => put(k, k === chu ? '추석' : '추석 연휴')); rules.push({ days, name: '추석', weekend: false }); }
    }
    for (const r of rules) {
      const hit = r.days.some((k) => dow(k) === 0 || (r.weekend && dow(k) === 6) || count.get(k) > 1);
      if (!hit) continue;
      let k = addDays(r.days[r.days.length - 1], 1);
      while (dow(k) === 0 || dow(k) === 6 || list.has(k)) k = addDays(k, 1);
      put(k, `대체공휴일(${r.name})`);
    }
    holCache[y] = list;
    return list;
  }
  function holidayInfo(today) {
    const y = Number(today.slice(0, 4));
    const all = new Map([...holidays(y), ...holidays(y + 1)]);
    if (all.has(today)) return { today: true, name: all.get(today) };
    const next = [...all.keys()].filter((k) => k > today).sort()[0];
    return next ? { today: false, k: next, name: all.get(next), dday: diffDays(next, today) } : null;
  }

  // ---------------------------------------------------------------- 저장소
  const STORE_KEY = 'tteum:v1';
  const blank = () => ({ v: 1, history: [], cycles: {}, likes: {}, marks: {}, words: [], reviews: {}, read: {}, settings: { fs: 1, auto: true, zodiac: null, hide: [], loc: null, tip: 0 } });
  let S = blank();
  let storeOK = false;
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      storeOK = true;
      if (raw) { const d = JSON.parse(raw); S = Object.assign(blank(), d); S.settings = Object.assign(blank().settings, d.settings || {}); }
    } catch (e) { storeOK = false; }
  }
  function save() { if (!storeOK) return; try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) { /* 저장 공간 부족 */ } }
  function cacheGet(k, maxAge) { try { const v = JSON.parse(localStorage.getItem('tteum:c:' + k) || 'null'); if (v && Date.now() - v.at < maxAge) return v.data; } catch (e) { /* 무시 */ } return null; }
  function cacheSet(k, data) { try { localStorage.setItem('tteum:c:' + k, JSON.stringify({ at: Date.now(), data })); } catch (e) { /* 무시 */ } }

  // ---------------------------------------------------------------- 데이터
  const D = { news: null, reading: null, arts: [], byArt: new Map(), pools: {}, glossAll: new Map(), fromCache: false };
  // 뉴스 파일을 바깥 주소(예: GitHub)에서 받으려면 index.html의 <meta name="tteum-data-base">에 폴더 주소를 넣어요.
  // 비워 두면 앱과 함께 올린 data/ 폴더를 써요.
  const DATA_BASE = ((document.querySelector('meta[name="tteum-data-base"]') || {}).content || '').trim();
  async function getJSON(u, opt = {}, ms = 0) {
    const ctl = ms && window.AbortController ? new AbortController() : null;
    const timer = ctl ? setTimeout(() => ctl.abort(), ms) : null;
    try {
      const r = await fetch(u, ctl ? Object.assign({}, opt, { signal: ctl.signal }) : opt);
      if (!r.ok) throw new Error(u + ' ' + r.status);
      return await r.json();
    } finally { if (timer) clearTimeout(timer); }
  }
  const dataCacheGet = (name) => { try { const c = localStorage.getItem('tteum:d:' + name); return c ? JSON.parse(c) : null; } catch (e) { return null; } };
  const dataCacheSet = (name, j) => { try { localStorage.setItem('tteum:d:' + name, JSON.stringify(j)); } catch (e) { /* 저장 공간 부족 */ } };
  // preferCache: 저장해 둔 파일이 있으면 그걸로 바로 화면을 띄우고, 새 파일은 뒤에서 확인해요(지하철처럼 느린 곳에서도 빨리 열리게).
  async function fetchData(name, opt = {}) {
    const local = `data/${name}`;
    if (!DATA_BASE) return getJSON(local, { cache: 'no-store' }, 10000);
    const cached = dataCacheGet(name);
    if (opt.preferCache && cached) { D.fromCache = true; return cached; }
    try {
      const j = await getJSON(DATA_BASE.replace(/\/?$/, '/') + name, { cache: 'no-store' }, 6000);
      dataCacheSet(name, j);
      return j;
    } catch (e) {
      if (cached) return cached;
      return getJSON(local);
    }
  }
  // 지난 기사 보관: 뉴스는 날마다 바뀌어서, 읽은 기사는 이 기기에 사본을 남겨 둬요.
  // 좋아요·형광펜이 있는 기사는 계속, 읽기만 한 기사는 최근 80건까지.
  const KEEP_KEY = 'tteum:keep';
  let KEEP = {};
  function keepLoad() { try { KEEP = JSON.parse(localStorage.getItem(KEEP_KEY) || '{}') || {}; } catch (e) { KEEP = {}; } }
  function keepSave() { try { localStorage.setItem(KEEP_KEY, JSON.stringify(KEEP)); } catch (e) { /* 저장 공간 부족 */ } }
  const keepPinned = (id) => !!(S.likes[`art:${id}`] || (S.marks[`a:${id}`] && S.marks[`a:${id}`].length));
  function keepArt(a) {
    if (!a || !a.id) return;
    const had = KEEP[a.id];
    if (had && had.a === a) return;
    KEEP[a.id] = { a, t: had ? had.t : Date.now() };
    const loose = Object.keys(KEEP).filter((id) => !keepPinned(id)).sort((x, y) => KEEP[y].t - KEEP[x].t);
    loose.slice(80).forEach((id) => { delete KEEP[id]; });
    keepSave();
  }
  const artById = (id) => D.byArt.get(id) || (KEEP[id] && KEEP[id].a) || null;
  const isPastArt = (id) => !D.byArt.has(id) && !!KEEP[id];
  function setData(news, reading) {
    if (news) D.news = news;
    if (reading) D.reading = reading;
    D.arts = [...((D.news && D.news.articles) || []), ...((D.reading && D.reading.articles) || [])];
    D.byArt = new Map(D.arts.map((a) => [a.id, a]));
    D.glossAll = new Map();
    for (const a of D.arts) for (const g of a.glossary || []) if (!D.glossAll.has(g.term)) D.glossAll.set(g.term, g);
  }
  async function loadData() {
    let news; let reading; let pools = {};
    if (window.__INLINE__) { news = window.__INLINE__.news; reading = window.__INLINE__.reading; pools = window.__INLINE__.daily; }
    else {
      const res = await Promise.all([fetchData('news.json', { preferCache: true }), fetchData('reading.json', { preferCache: true }).catch(() => ({ articles: [] })), ...DAILY_CATS.map((c) => fetchData(`daily/${c.key}.json`, { preferCache: true }))]);
      news = res[0]; reading = res[1];
      DAILY_CATS.forEach((c, i) => { pools[c.key] = res[i + 2]; });
    }
    setData(news, reading || { articles: [] });
    for (const c of DAILY_CATS) setPool(c.key, pools[c.key]);
  }
  function setPool(key, p) {
    p = p || { items: [] };
    p.items = p.items || [];
    p.byId = new Map(p.items.map((it) => [it.id, it]));
    D.pools[key] = p;
  }
  // 카드 묶음 새로 받기: 예약 작업이 카드를 더하면 앱을 다시 올리지 않아도 여기서 받아요.
  async function refreshPools() {
    if (!DATA_BASE) return 0;
    let added = 0;
    await Promise.all(DAILY_CATS.map(async (c) => {
      try {
        const p = await fetchData(`daily/${c.key}.json`);
        const old = D.pools[c.key] || { items: [] };
        if (p && Array.isArray(p.items) && (p.items.length !== old.items.length || p.updatedAt !== old.updatedAt)) {
          added += Math.max(0, p.items.length - old.items.length);
          setPool(c.key, p);
        }
      } catch (e) { /* 다음에 다시 */ }
    }));
    return added;
  }
  function editionLabel() {
    const u = D.news && D.news.updatedAt;
    if (!u) return '';
    const k = u.slice(0, 10); const h = Number(u.slice(11, 13));
    const part = h < 6 ? '새벽' : h < 12 ? '오전' : h < 18 ? '오후' : '저녁';
    const hh = h % 12 === 0 ? 12 : h % 12;
    return `${dateLabel(k)} ${part} ${hh}시 기준`;
  }
  // 새 소식 확인: 조사해서 올린 최신 news.json이 있으면 바꿔 끼워요(앱이 직접 조사하지는 않아요).
  let lastNewsCheck = Date.now();
  async function checkNews(manual) {
    if (PREVIEW) { if (manual) toast('미리보기에서는 새 소식을 받아 올 수 없어요'); return; }
    lastNewsCheck = Date.now();
    try {
      const [n, rd, cardsAdded] = await Promise.all([fetchData('news.json'), fetchData('reading.json').catch(() => null), refreshPools()]);
      const newNews = n && n.updatedAt && n.updatedAt !== (D.news || {}).updatedAt ? n : null;
      const newReading = rd && rd.updatedAt && rd.updatedAt !== (D.reading || {}).updatedAt ? rd : null;
      if (newNews || newReading) {
        setData(newNews, newReading);
        const r = route();
        if (r === 'home' || r.startsWith('news-') || r === 'settings') render();
        toast(newNews ? `새 소식을 받았어요 · ${editionLabel()}` : '새 읽을거리를 받았어요');
      } else if (cardsAdded > 0) {
        toast(`새 카드 ${cardsAdded}장이 들어왔어요`);
      } else if (manual) toast(`지금이 가장 최근 소식이에요 · ${editionLabel()}`);
    } catch (e) { if (manual) toast('새 소식을 받아 오지 못했어요. 인터넷 연결을 확인해 주세요'); }
  }

  // ---------------------------------------------------------------- 오늘의 한 장 알고리즘
  // 1) 아직 안 본 카드에서만 고르고, 다 보면 새 바퀴를 시작해요(최근 본 카드는 빼고).
  // 2) 날짜+분야+바퀴+순번을 씨앗으로 섞어서 같은 날엔 같은 카드가 나와요.
  // 3) 처음 10장은 쉬운 카드 위주, 25장 이후엔 난이도를 고르게.
  // 4) 좋아요 누른 카드와 같은 태그는 가중치↑, 어제 카드와 같은 태그는 가중치↓.
  // 5) 1·3·7·14·30일 전에 본 카드는 복습으로 다시 보여 줘요.
  const Daily = {
    item(cat, id) { const p = D.pools[cat]; return p ? p.byId.get(id) : null; },
    entries(cat, dk) { return S.history.filter((h) => h.c === cat && h.d === dk).sort((a, b) => a.n - b.n); },
    ensure(cat, dk) {
      const e = this.entries(cat, dk);
      if (e.length || !D.pools[cat] || !D.pools[cat].items.length) return e;
      this.pick(cat, dk, 0);
      return this.entries(cat, dk);
    },
    more(cat, dk) { return this.pick(cat, dk, this.entries(cat, dk).length); },
    seen(cat, cy) { return new Set(S.history.filter((h) => h.c === cat && (h.cy || 0) === cy).map((h) => h.id)); },
    remaining(cat) {
      const p = D.pools[cat]; if (!p) return 0;
      const seen = this.seen(cat, S.cycles[cat] || 0);
      return p.items.filter((it) => !seen.has(it.id)).length;
    },
    pick(cat, dk, n, demo = false) {
      const items = D.pools[cat].items;
      let cy = S.cycles[cat] || 0;
      const seen = this.seen(cat, cy);
      let cands = items.filter((it) => !seen.has(it.id));
      if (!cands.length) {
        cy += 1; S.cycles[cat] = cy;
        const recentN = Math.min(10, Math.floor(items.length / 3));
        const recent = new Set(S.history.filter((h) => h.c === cat).slice(-recentN).map((h) => h.id));
        cands = items.filter((it) => !recent.has(it.id));
        if (!cands.length) cands = items.slice();
      }
      const learned = S.history.filter((h) => h.c === cat).length;
      const stage = learned < 10 ? 0 : learned < 25 ? 1 : 2;
      const levelW = [[1.7, 0.9, 0.35], [1.15, 1.1, 0.8], [1, 1, 1]][stage];
      const likedTags = {};
      for (const v of Object.values(S.likes)) if (v.type === 'card' && v.cat === cat) (v.tags || []).forEach((t) => { likedTags[t] = (likedTags[t] || 0) + 1; });
      const prevEntry = S.history.filter((h) => h.c === cat && (h.d < dk || (h.d === dk && h.n < n))).slice(-1)[0];
      const prevItem = prevEntry ? this.item(cat, prevEntry.id) : null;
      const prevTags = new Set(prevItem && prevItem.tags ? prevItem.tags : []);
      const weights = cands.map((it) => {
        let w = levelW[clamp((it.level || 1) - 1, 0, 2)];
        const tags = it.tags || [];
        const boost = tags.reduce((s, t) => s + (likedTags[t] || 0), 0);
        w *= 1 + Math.min(boost, 3) * 0.35;
        if (tags.some((t) => prevTags.has(t))) w *= 0.6;
        return w;
      });
      const rng = mulberry32(hashStr(`${dk}|${cat}|${cy}|${n}`));
      const it = weightedPick(cands, weights, rng);
      const entry = { d: dk, c: cat, id: it.id, n, cy, t: Date.now() };
      if (demo) entry.demo = true;
      S.history.push(entry);
      sortHistory();
      save();
      return entry;
    },
    backfill(days) {
      const today = nowKST().key; let made = 0;
      for (let i = days; i >= 1; i--) {
        const dk = addDays(today, -i);
        for (const c of DAILY_CATS) if (D.pools[c.key].items.length && !this.entries(c.key, dk).length) { this.pick(c.key, dk, 0, true); made++; }
      }
      return made;
    },
    reviewList(today) {
      const iv = [1, 3, 7, 14, 30]; const seen = new Set(); const out = [];
      for (let i = S.history.length - 1; i >= 0; i--) {
        const h = S.history[i]; const key = `${h.c}:${h.id}`;
        if (seen.has(key)) continue;
        const age = diffDays(today, h.d);
        if (age <= 0) continue;
        const r = S.reviews[key];
        if (r && r.last === today) continue;
        const due = r && r.again && r.again <= today;
        if (iv.includes(age) || due) { seen.add(key); if (this.item(h.c, h.id)) out.push(Object.assign({ age }, h)); }
        if (out.length >= 6) break;
      }
      return out;
    },
  };
  function sortHistory() { S.history.sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : a.c < b.c ? -1 : a.c > b.c ? 1 : a.n - b.n)); }

  // ---------------------------------------------------------------- 띠 운세 (일진과 띠의 합·충)
  const YUKHAP = [[0, 1], [2, 11], [3, 10], [4, 9], [5, 8], [6, 7]];
  const SAMHAP = [[8, 0, 4], [11, 3, 7], [2, 6, 10], [5, 9, 1]];
  function relation(day, me) {
    if (day === me) return { key: 'same', label: '같은 띠의 날', tone: 1, desc: '오늘 일진의 띠가 내 띠와 같아요. 익숙한 일에서 힘이 나는 날로 봐요.' };
    if (YUKHAP.some(([a, b]) => (a === day && b === me) || (b === day && a === me))) return { key: 'yukhap', label: '육합(六合)', tone: 2, desc: '일진과 내 띠가 육합을 이뤄요. 사람과 일이 잘 맞물리는 날로 봐요.' };
    if (SAMHAP.some((g) => g.includes(day) && g.includes(me))) return { key: 'samhap', label: '삼합(三合)', tone: 2, desc: '일진과 내 띠가 삼합을 이뤄요. 뜻 맞는 사람과 힘을 모으기 좋은 날로 봐요.' };
    if ((day - me + 12) % 12 === 6) return { key: 'chung', label: '충(沖)', tone: -1, desc: '일진과 내 띠가 충이에요. 부딪히기 쉬우니 조심스럽게 움직이는 날로 봐요.' };
    return { key: 'plain', label: '평범한 날', tone: 0, desc: '일진과 내 띠 사이에 특별한 합이나 충이 없는 무난한 날이에요.' };
  }
  const F_MSG = {
    총운: { hi: ['하려던 일에 속도가 붙는 날이에요.', '작은 행운이 이어져요. 미뤄 둔 일을 시작해 보세요.', '주변의 도움으로 일이 술술 풀려요.'], mid: ['무난하게 흘러가는 하루예요. 평소 속도를 지키세요.', '크게 나쁠 것 없는 날이에요. 기본에 충실하면 충분해요.', '계획한 만큼만 하면 되는 날이에요.'], lo: ['서두르면 꼬이기 쉬운 날이에요. 한 박자 쉬어 가세요.', '예상 밖의 변수가 생길 수 있어요. 여유 시간을 두세요.', '무리한 약속은 미루는 게 좋아요.'] },
    돈: { hi: ['뜻밖의 절약이나 작은 수입이 생길 수 있어요.', '계획해 둔 지출이 잘 맞아떨어져요.', '비교해 보고 사면 이득을 봐요.'], mid: ['필요한 곳에만 쓰면 무난해요.', '큰 지출보다 작은 정리가 어울리는 날이에요.', '가계부를 한 번 훑어보기 좋은 날이에요.'], lo: ['충동구매를 조심하세요. 장바구니는 하루 묵혀 두세요.', '돈을 빌리고 빌려주는 일은 오늘은 피하세요.', '작은 지출이 쌓이기 쉬운 날이에요.'] },
    '일·공부': { hi: ['집중이 잘돼 어려운 일을 끝내기 좋아요.', '아이디어가 잘 떠오르는 날이에요. 메모해 두세요.', '보고나 발표에서 좋은 반응을 얻어요.'], mid: ['쌓인 일을 하나씩 정리하기 좋은 날이에요.', '새 일보다 하던 일을 마무리하세요.', '꼼꼼함이 빛을 보는 날이에요.'], lo: ['실수하기 쉬우니 한 번 더 확인하세요.', '큰 결정은 서두르지 말고 내일로 미뤄도 괜찮아요.', '메일은 보내기 전에 다시 읽어 보세요.'] },
    사람: { hi: ['반가운 연락이 올 수 있어요.', '먼저 건넨 인사가 좋은 인연으로 이어져요.', '함께하면 일이 더 쉬워지는 날이에요.'], mid: ['가벼운 대화가 분위기를 부드럽게 해요.', '들어 주는 쪽이 되면 좋은 날이에요.', '오랜만에 안부를 전해 보세요.'], lo: ['말 한마디가 오해를 부를 수 있어요. 부드럽게 말하세요.', '의견이 부딪히면 한발 물러서는 게 나아요.', '남의 일에 너무 깊이 끼어들지 마세요.'] },
    건강: { hi: ['몸이 가벼운 날이에요. 한 정거장 먼저 내려 걸어 보세요.', '컨디션이 좋아요. 가벼운 운동이 잘 맞아요.', '잠을 푹 자면 좋은 기운이 내일까지 이어져요.'], mid: ['물을 자주 마시고 틈틈이 스트레칭하세요.', '무리하지 않으면 무난해요.', '점심 뒤 짧은 산책이 도움이 돼요.'], lo: ['피로가 쌓이기 쉬워요. 오늘은 일찍 쉬세요.', '목과 어깨를 자주 풀어 주세요.', '과식과 늦은 야식은 피하세요.'] },
  };
  const F_TIPS = ['오늘 배운 한 장을 누군가에게 이야기해 보세요.', '출근길에 한 정거장 먼저 내려 걸어 보세요.', '물 한 컵으로 하루를 시작해 보세요.', '미뤄 둔 연락 하나를 오늘 해 보세요.', '책상 위를 5분만 정리해 보세요.', '점심 뒤 10분 산책이 오후를 바꿔요.', '고마운 일 세 가지를 떠올려 보세요.', '오늘 할 일을 딱 세 개만 적어 보세요.', '좋아하는 노래 한 곡으로 기분을 바꿔 보세요.', '어려운 말은 형광펜으로 칠해 두고 찾아보세요.', '가까운 사람에게 먼저 안부를 물어보세요.', '잠들기 전 휴대폰은 조금 일찍 내려놓아 보세요.'];
  function fortune(today, z) {
    const g = ganji(today); const rel = relation(g.b, z);
    const rng = mulberry32(hashStr(`fortune|${today}|${z}`));
    const base = { 2: 4.1, 1: 3.6, 0: 3.1, '-1': 2.2 }[rel.tone];
    const areas = Object.keys(F_MSG).map((name) => {
      const sc = clamp(Math.round(base + (rng() * 1.8 - 0.9)), 1, 5);
      const band = sc >= 4 ? 'hi' : sc === 3 ? 'mid' : 'lo';
      return { name, sc, msg: pickFrom(F_MSG[name][band], rng) };
    });
    const el = EL_INFO[STEM_EL[g.s]];
    return { g, rel, areas, el, tip: pickFrom(F_TIPS, rng) };
  }
  const stars = (n) => `<span class="stars" aria-label="5점 만점에 ${n}점">${'<i class="on"></i>'.repeat(n)}${'<i></i>'.repeat(5 - n)}</span>`;

  // ---------------------------------------------------------------- 날씨 (Open-Meteo, 무료·키 없음)
  function wxInfo(c, isDay = 1) {
    if (c === 0) return ['맑음', isDay ? 'sun' : 'moon'];
    if (c === 1) return ['대체로 맑음', isDay ? 'sun' : 'moon'];
    if (c === 2) return ['구름 조금', 'partly'];
    if (c === 3) return ['흐림', 'cloud'];
    if (c === 45 || c === 48) return ['안개', 'fog'];
    if (c >= 51 && c <= 57) return ['이슬비', 'rain'];
    if (c >= 61 && c <= 67) return [c >= 65 ? '강한 비' : '비', 'rain'];
    if (c >= 71 && c <= 77) return ['눈', 'snow'];
    if (c >= 80 && c <= 82) return ['소나기', 'rain'];
    if (c === 85 || c === 86) return ['소낙눈', 'snow'];
    if (c >= 95) return ['뇌우', 'storm'];
    return ['흐림', 'cloud'];
  }
  const pmGrade = (v, cut) => (v == null ? null : v <= cut[0] ? ['좋음', 'good'] : v <= cut[1] ? ['보통', 'fair'] : v <= cut[2] ? ['나쁨', 'poor'] : ['매우 나쁨', 'bad']);
  const uvGrade = (v) => (v == null ? null : v < 3 ? ['낮음', 'good'] : v < 6 ? ['보통', 'fair'] : v < 8 ? ['높음', 'poor'] : ['매우 높음', 'bad']);
  function commuteSlots(today, hour) {
    const tm = addDays(today, 1);
    if (hour < 8) return [{ k: today, h: 8, label: '출근 8시' }, { k: today, h: 18, label: '퇴근 6시' }];
    if (hour < 18) return [{ k: today, h: 18, label: '퇴근 6시' }, { k: tm, h: 8, label: '내일 출근' }];
    return [{ k: tm, h: 8, label: '내일 출근' }, { k: tm, h: 18, label: '내일 퇴근' }];
  }
  const Weather = {
    loc() { return S.settings.loc || LOCS[0]; },
    skeleton() { return `<div class="wx-skel"><span class="skel skel-a"></span><span class="skel skel-b"></span><span class="skel skel-c"></span></div>`; },
    async mount(force = false) {
      const el = document.getElementById('wx'); if (!el) return;
      const loc = this.loc();
      if (PREVIEW) { el.innerHTML = `<div class="wx-note">${icon('sun', 'wx-note-ico')}<div><b>실시간 날씨 자리</b><p>미리보기 화면에서는 바깥 날씨 정보를 불러올 수 없어요. Netlify에 올린 앱에서는 ${esc(loc.name)}의 지금 날씨와 출퇴근 시간 예보, 미세먼지가 여기에 떠요.</p></div></div>`; return; }
      const ck = `wx:${loc.lat.toFixed(2)},${loc.lon.toFixed(2)}`;
      let data = force ? null : cacheGet(ck, 20 * 60000);
      if (!data) {
        if (force) el.innerHTML = this.skeleton();
        try { data = await this.fetch(loc); cacheSet(ck, data); }
        catch (e) { if (document.getElementById('wx') === el) el.innerHTML = `<div class="wx-note">${icon('cloud', 'wx-note-ico')}<div><b>날씨를 불러오지 못했어요</b><p>인터넷 연결을 확인한 뒤 다시 시도해 주세요.</p><button class="btn-ghost sm" data-act="wx-retry">${icon('refresh')} 다시 불러오기</button></div></div>`; return; }
      }
      if (document.getElementById('wx') === el) el.innerHTML = this.html(data, loc);
    },
    async fetch(loc) {
      const base = `latitude=${loc.lat}&longitude=${loc.lon}&timezone=Asia%2FSeoul`;
      const fu = `https://api.open-meteo.com/v1/forecast?${base}&current=temperature_2m,apparent_temperature,weather_code,is_day,precipitation&hourly=temperature_2m,precipitation_probability,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max&forecast_days=2`;
      const au = `https://air-quality-api.open-meteo.com/v1/air-quality?${base}&current=pm10,pm2_5`;
      const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 9000);
      try {
        const [f, a] = await Promise.all([
          fetch(fu, { signal: ctl.signal }).then((r) => (r.ok ? r.json() : Promise.reject(new Error('wx ' + r.status)))),
          fetch(au, { signal: ctl.signal }).then((r) => (r.ok ? r.json() : null)).catch(() => null),
        ]);
        return { f, a, at: Date.now() };
      } finally { clearTimeout(tm); }
    },
    html(data, loc) {
      const f = data.f || {}; const cur = f.current || {}; const dl = f.daily || {}; const hr = f.hourly || {};
      const { key: today, hour } = nowKST();
      const [label, ic] = wxInfo(cur.weather_code, cur.is_day);
      const di = Math.max(0, (dl.time || []).indexOf(today));
      const tmax = Math.round((dl.temperature_2m_max || [])[di]); const tmin = Math.round((dl.temperature_2m_min || [])[di]);
      const pmax = (dl.precipitation_probability_max || [])[di]; const uv = (dl.uv_index_max || [])[di];
      const slots = commuteSlots(today, hour).map((s) => {
        const idx = (hr.time || []).indexOf(`${s.k}T${String(s.h).padStart(2, '0')}:00`);
        if (idx < 0) return null;
        const w = wxInfo(hr.weather_code[idx], s.h >= 6 && s.h < 19 ? 1 : 0);
        return { label: s.label, t: Math.round(hr.temperature_2m[idx]), p: (hr.precipitation_probability || [])[idx] || 0, ic: w[1], l: w[0] };
      }).filter(Boolean);
      const aq = (data.a && data.a.current) || {};
      const g10 = pmGrade(aq.pm10, [30, 80, 150]); const g25 = pmGrade(aq.pm2_5, [15, 35, 75]); const gu = uvGrade(uv);
      const wet = slots.find((s) => s.p >= 50);
      let tip;
      if ((cur.precipitation || 0) > 0) tip = ['umbrella', '지금 비나 눈이 오고 있어요. 우산 챙기세요.'];
      else if (wet) tip = ['umbrella', `${wet.label} 무렵 비 올 확률이 ${wet.p}%예요. 우산 챙기세요.`];
      else if (pmax >= 50) tip = ['umbrella', `오늘 비 올 확률이 ${pmax}%예요. 우산 챙기세요.`];
      else if (pmax >= 30) tip = ['umbrella', `비 올 확률 ${pmax}%예요. 작은 우산이 있으면 든든해요.`];
      else if ((g25 && (g25[1] === 'poor' || g25[1] === 'bad')) || (g10 && (g10[1] === 'poor' || g10[1] === 'bad'))) tip = ['cloud', '공기가 탁해요. 마스크를 챙기세요.'];
      else if (tmax - tmin >= 10) tip = ['sun', `일교차가 ${tmax - tmin}°나 돼요. 얇은 겉옷을 챙기세요.`];
      else if (uv >= 6) tip = ['sun', '자외선이 강해요. 선크림을 챙기세요.'];
      else tip = ['check', '우산 없이 가볍게 나서도 괜찮은 날이에요.'];
      const chip = (name, g) => (g ? `<span class="chip ${g[1]}">${name} ${g[0]}</span>` : '');
      return `
        <div class="wx-now">
          ${icon(ic, 'wx-big')}
          <span class="wx-temp">${Math.round(cur.temperature_2m)}°</span>
          <div class="wx-desc"><b>${label}</b><span>${esc(loc.name)} · 체감 ${Math.round(cur.apparent_temperature)}°</span><span>최고 ${tmax}° · 최저 ${tmin}°</span></div>
        </div>
        <div class="wx-commute">${slots.map((s) => `<div class="wx-slot"><span class="k">${s.label}</span>${icon(s.ic)}<b>${s.t}°</b><span class="p" aria-label="비 올 확률">${icon('umbrella')}${s.p}%</span></div>`).join('')}</div>
        <div class="wx-chips">${chip('미세먼지', g10)}${chip('초미세먼지', g25)}${chip('자외선', gu)}</div>
        <p class="wx-tip">${icon(tip[0])}<span>${tip[1]}</span></p>`;
    },
  };

  // ---------------------------------------------------------------- 카드 그리기
  function cardHead(cat, it) {
    switch (cat) {
      case 'proverb': return [it.text, it.meaning];
      case 'idiom': return [`${it.word} ${it.hanja}`, it.meaning];
      case 'trivia': case 'origin': return [it.title, it.answer];
      case 'word': return [it.title, it.kind === '순우리말' ? it.meaning : (it.tip || it.body)];
      default: return ['', ''];
    }
  }
  const para = (pid, text, cls = '') => (text ? `<p data-pid="${pid}"${cls ? ` class="${cls}"` : ''}>${esc(text)}</p>` : '');
  function cardBody(cat, it) {
    const doc = `c:${cat}:${it.id}`;
    const open = `<div class="readable" data-doc="${doc}">`;
    const src = it.source && safeUrl(it.source.url) ? `<a class="card-src" href="${esc(safeUrl(it.source.url))}" target="_blank" rel="noopener">출처 · ${esc(it.source.name || '바로가기')} ${icon('ext')}</a>` : '';
    switch (cat) {
      case 'proverb': return `
        <p class="card-kicker" style="--c:${dailyCat(cat).color}">속담</p>
        <h2 class="card-main serif">${esc(it.text)}</h2>
        ${open}${para(0, it.meaning, 'card-meaning')}${para(1, it.example ? `“${it.example}”` : '', 'card-example')}${para(2, it.note, 'card-note')}</div>
        ${it.similar && it.similar.length ? `<div class="card-similar"><span class="mini-h">비슷한 말</span><div class="chips">${it.similar.map((s) => `<span class="chip">${esc(s)}</span>`).join('')}</div></div>` : ''}`;
      case 'idiom': return `
        <p class="card-kicker" style="--c:${dailyCat(cat).color}">사자성어</p>
        <div class="hanja-row" lang="ko">${(it.chars || []).map(([h, r]) => `<div class="hanja-cell"><span class="hj">${esc(h)}</span><span class="hr">${esc(r)}</span></div>`).join('')}</div>
        <h2 class="card-main">${esc(it.word)} <span class="card-hanja">${esc(it.hanja)}</span></h2>
        ${open}${para(0, it.meaning, 'card-meaning')}
        ${it.story ? `<h3 class="mini-h">어디서 나온 말일까?</h3>${para(1, it.story)}` : ''}
        ${it.source ? `<p class="card-source">출전 · ${esc(it.source)}</p>` : ''}
        ${para(2, it.note, 'card-note')}${para(3, it.example ? `“${it.example}”` : '', 'card-example')}</div>
        ${it.similar && it.similar.length ? `<div class="card-similar"><span class="mini-h">비슷한 말</span><div class="chips">${it.similar.map((s) => `<span class="chip">${esc(s)}</span>`).join('')}</div></div>` : ''}`;
      case 'trivia': return `
        <p class="card-kicker" style="--c:${dailyCat(cat).color}">오늘의 상식</p>
        <h2 class="card-main">${esc(it.title)}</h2>
        <p class="card-answer"><span class="hl-text">${esc(it.answer)}</span></p>
        ${open}${para(0, it.body)}</div>${src}`;
      case 'origin': return `
        <p class="card-kicker" style="--c:${dailyCat(cat).color}">알고 보면 유래${it.kind ? ` · ${esc(it.kind)}` : ''}</p>
        <h2 class="card-main">${esc(it.title)}</h2>
        <p class="card-answer"><span class="hl-text">${esc(it.answer)}</span></p>
        ${it.reliability ? `<p class="badge-line"><span class="badge rel-${relClass(it.reliability)}">${esc(it.reliability)}</span></p>` : ''}
        ${open}${para(0, it.body)}</div>${src}`;
      case 'word':
        if (it.kind === '순우리말') return `
          <p class="card-kicker" style="--c:${dailyCat(cat).color}">오늘의 우리말 · 순우리말</p>
          <h2 class="card-main serif card-word">${esc(it.right)}</h2>
          <p class="card-answer"><span class="hl-text">${esc(it.meaning)}</span></p>
          ${open}${para(0, it.body)}${para(1, it.example ? `“${it.example}”` : '', 'card-example')}</div>${src}`;
        return `
          <p class="card-kicker" style="--c:${dailyCat(cat).color}">오늘의 우리말 · 맞춤법</p>
          <div class="spell">
            <span class="spell-right">${icon('check')}${esc(it.right)}</span>
            ${it.wrong ? `<span class="spell-wrong"><s>${esc(it.wrong)}</s></span>` : ''}
          </div>
          ${open}${para(0, it.body)}${para(1, it.example ? `“${it.example}”` : '', 'card-example')}</div>
          ${it.tip ? `<p class="card-tip">${icon('bulb')}<span>${esc(it.tip)}</span></p>` : ''}${src}`;
      default: return '';
    }
  }
  const relClass = (r) => ({ 정설: 'sure', '유력한 설': 'likely', '여러 설': 'multi', '속설 바로잡기': 'myth' }[r] || 'multi');

  // ---------------------------------------------------------------- 좋아요
  const likeKeyCard = (cat, id) => `card:${cat}:${id}`;
  const likeKeyArt = (id) => `art:${id}`;
  function toggleLike(key, snap) {
    if (S.likes[key]) { delete S.likes[key]; save(); toast('좋아요를 취소했어요'); return false; }
    S.likes[key] = Object.assign({ t: Date.now() }, snap); save(); toast('좋아요에 담았어요'); return true;
  }
  function likeCard(cat, id) {
    const it = Daily.item(cat, id); if (!it) return false;
    const [head, sub] = cardHead(cat, it);
    return toggleLike(likeKeyCard(cat, id), { type: 'card', cat, id, head, sub, tags: it.tags || [] });
  }
  function likeArt(id) {
    const a = artById(id); if (!a) return false;
    keepArt(a);
    return toggleLike(likeKeyArt(id), { type: 'art', id, cat: a.cat, head: a.title, sub: a.dek });
  }
  const likeBtn = (on, act, attrs) => `<button class="like-btn ${on ? 'on' : ''}" data-act="${act}" ${attrs} aria-pressed="${on}" aria-label="${on ? '좋아요 취소' : '좋아요'}">${icon(on ? 'heart-fill' : 'heart')}<span>${on ? '좋아요 함' : '좋아요'}</span></button>`;

  // ---------------------------------------------------------------- 형광펜
  function offsetIn(root, node, off) { const r = document.createRange(); r.selectNodeContents(root); r.setEnd(node, off); return r.toString().length; }
  function wrapRange(pEl, mk) {
    const walker = document.createTreeWalker(pEl, NodeFilter.SHOW_TEXT);
    let pos = 0; let n; const targets = [];
    while ((n = walker.nextNode())) {
      const len = n.nodeValue.length;
      const a = Math.max(mk.s, pos); const b = Math.min(mk.s + mk.l, pos + len);
      if (a < b) targets.push([n, a - pos, b - pos]);
      pos += len;
      if (pos >= mk.s + mk.l) break;
    }
    const made = [];
    for (const [node, a, b] of targets) {
      let mid = node;
      if (a > 0) mid = node.splitText(a);
      if (b - a < mid.nodeValue.length) mid.splitText(b - a);
      const m = document.createElement('mark');
      m.className = 'hl'; m.dataset.p = mk.p; m.dataset.s = mk.s; m.dataset.l = mk.l;
      mid.parentNode.insertBefore(m, mid); m.appendChild(mid);
      made.push(m);
    }
    return made;
  }
  function applyMarks(scope) {
    $$('.readable[data-doc]', scope || document).forEach((host) => {
      const list = S.marks[host.dataset.doc] || [];
      for (const mk of list) {
        const pEl = host.querySelector(`[data-pid="${mk.p}"]`); if (!pEl) continue;
        const txt = pEl.textContent;
        if (txt.substr(mk.s, mk.l) !== mk.t) { const i = txt.indexOf(mk.t); if (i < 0) continue; mk.s = i; }
        const m = wrapRange(pEl, mk); m.forEach((x) => x.classList.add('static'));
      }
    });
  }
  function unwrapMark(host, mk) {
    $$(`mark.hl[data-p="${mk.p}"][data-s="${mk.s}"]`, host).forEach((m) => { const p = m.parentNode; while (m.firstChild) p.insertBefore(m.firstChild, m); p.removeChild(m); p.normalize(); });
  }
  function docTitle(doc) {
    if (!doc) return '';
    if (doc.startsWith('a:')) { const a = artById(doc.slice(2)); return a ? a.title : '기사'; }
    if (doc.startsWith('c:')) { const [, cat, id] = doc.split(':'); const it = Daily.item(cat, id); return it ? `${dailyCat(cat).label} · ${cardHead(cat, it)[0]}` : '카드'; }
    return '';
  }
  const HL = {
    timer: 0,
    init() {
      document.addEventListener('selectionchange', () => {
        clearTimeout(this.timer);
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed || !sel.rangeCount) { hideChip(); return; }
        const r = sel.getRangeAt(0);
        const host = closestEl(r.commonAncestorContainer, '.readable');
        if (!host) { hideChip(); return; }
        if (S.settings.auto) this.timer = setTimeout(() => this.commit(), 900);
        else showChip(r);
      });
      document.addEventListener('mouseup', () => {
        if (!S.settings.auto) return;
        const sel = window.getSelection();
        if (sel && !sel.isCollapsed) { clearTimeout(this.timer); this.timer = setTimeout(() => this.commit(), 220); }
      });
    },
    commit() {
      hideChip();
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount) return;
      const range = sel.getRangeAt(0);
      const host = closestEl(range.commonAncestorContainer, '.readable');
      if (!host) return;
      const pEl = closestEl(range.startContainer, '[data-pid]');
      const pEnd = closestEl(range.endContainer, '[data-pid]');
      if (!pEl || pEl !== pEnd || !host.contains(pEl)) { sel.removeAllRanges(); toast('한 문단 안에서 골라 주세요'); return; }
      const raw = range.toString();
      const t = raw.trim();
      if (!t) return;
      if (t.length > 40) { sel.removeAllRanges(); toast('40자 이내로 골라 주세요'); return; }
      const s = offsetIn(pEl, range.startContainer, range.startOffset) + (raw.length - raw.trimStart().length);
      const doc = host.dataset.doc;
      const mk = { p: pEl.dataset.pid, s, l: t.length, t };
      sel.removeAllRanges();
      const list = S.marks[doc] || (S.marks[doc] = []);
      if (!list.some((m) => m.p === mk.p && m.s === mk.s && m.l === mk.l)) {
        list.push(mk);
        wrapRange(pEl, mk);
      }
      if (!S.words.some((w) => w.t === t && w.doc === doc)) S.words.unshift({ t, doc, mk, at: Date.now() });
      S.words = S.words.slice(0, 500);
      save();
      Lookup.open(t, { doc, mk });
    },
    remove(doc, mk) {
      const list = S.marks[doc] || [];
      S.marks[doc] = list.filter((m) => !(m.p === mk.p && m.s === mk.s && m.l === mk.l));
      if (!S.marks[doc].length) delete S.marks[doc];
      S.words = S.words.filter((w) => !(w.doc === doc && w.mk && w.mk.p === mk.p && w.mk.s === mk.s && w.mk.l === mk.l) && !(w.doc === doc && w.t === mk.t));
      save();
      $$(`.readable[data-doc="${cssEsc(doc)}"]`).forEach((host) => unwrapMark(host, mk));
    },
  };
  const cssEsc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/["\\]/g, '\\$&'));
  function closestEl(node, sel) { const el = node && (node.nodeType === 1 ? node : node.parentElement); return el ? el.closest(sel) : null; }
  function showChip(range) {
    const chip = document.getElementById('hl-chip'); if (!chip) return;
    const rect = range.getBoundingClientRect();
    chip.hidden = false;
    const top = clamp(rect.bottom + 10, 70, window.innerHeight - 140);
    const left = clamp(rect.left + rect.width / 2 - chip.offsetWidth / 2, 12, window.innerWidth - chip.offsetWidth - 12);
    chip.style.top = `${top}px`; chip.style.left = `${left}px`;
  }
  function hideChip() { const chip = document.getElementById('hl-chip'); if (chip) chip.hidden = true; }

  // ---------------------------------------------------------------- 찾아보기
  const JOSA = ['으로부터', '에서부터', '이라는', '이라고', '에게서', '으로서', '으로써', '에서는', '에서도', '에서의', '까지는', '부터는', '에게는', '에게', '에서', '으로', '부터', '까지', '처럼', '보다', '라는', '라고', '를', '을', '은', '는'];
  const NOT_JOSA = ['마을', '가을', '노을', '고을'];
  function cleanQuery(s) {
    let t = String(s).trim().replace(/^[\s"'“”‘’(\[「『]+|[\s"'“”‘’.,!?·…)\]」』]+$/g, '');
    if (/\s/.test(t)) return t;
    if (NOT_JOSA.some((w) => t.endsWith(w))) return t;
    for (const j of JOSA) if (t.length >= j.length + 2 && t.endsWith(j)) return t.slice(0, -j.length);
    return t;
  }
  function findGloss(text, doc) {
    const q = cleanQuery(text);
    const local = doc && doc.startsWith('a:') ? (artById(doc.slice(2)) || {}).glossary || [] : [];
    const hit = (g) => g.term === text || g.term === q || (q.length >= 2 && (g.term.includes(q) || q.includes(g.term)));
    return local.find(hit) || [...D.glossAll.values()].find((g) => g.term === q || g.term === text) || null;
  }
  const Lookup = {
    tok: 0,
    urls(q) {
      const e = encodeURIComponent(q);
      return {
        dict: `https://ko.dict.naver.com/#/search?query=${e}`,
        stdict: `https://stdict.korean.go.kr/search/searchResult.do?pageSize=10&searchKeyword=${e}`,
        naver: `https://search.naver.com/search.naver?query=${e}`,
        wiki: `https://ko.wikipedia.org/w/index.php?search=${e}`,
      };
    },
    open(text, opt = {}) {
      const q = opt.q || cleanQuery(text);
      const g = opt.gloss || findGloss(text, opt.doc);
      const u = this.urls(q);
      const markInfo = opt.mk ? `<div class="lk-foot"><span class="muted small">${icon('marker')} 형광펜을 칠하고 단어장에 담았어요</span><button class="btn-ghost sm danger" data-act="unmark" data-doc="${esc(opt.doc)}" data-p="${esc(opt.mk.p)}" data-s="${opt.mk.s}" data-l="${opt.mk.l}" data-t="${esc(opt.mk.t)}">형광펜 지우기</button></div>` : '';
      openSheet(`
        <div class="lk">
          <p class="eyebrow">${opt.mk ? '형광펜으로 칠한 말' : '찾아보기'}</p>
          <h2 class="lk-term"><span class="hl-text">${esc(text)}</span></h2>
          ${opt.doc ? `<p class="muted small lk-from">${esc(docTitle(opt.doc))}</p>` : ''}
          ${g ? `<section class="lk-gloss"><h3 class="mini-h">쉬운 풀이 · ${esc(g.term)}</h3><p class="lk-short">${esc(g.short)}</p><p>${esc(g.long)}</p></section>` : ''}
          <section class="lk-wiki" id="lk-wiki" aria-live="polite"><h3 class="mini-h">위키백과 요약</h3><p class="muted">불러오는 중…</p></section>
          <section class="lk-search">
            <label class="mini-h" for="lk-q">검색어 (조사를 빼거나 고칠 수 있어요)</label>
            <form class="lk-form" data-form="lookup"><input id="lk-q" class="input" value="${esc(q)}" autocomplete="off" autocapitalize="off" enterkeyhint="search"><button class="btn-ghost sm" type="submit">${icon('search')} 다시 찾기</button></form>
            <div class="lk-btns">
              <a class="lk-btn" data-lk="dict" href="${u.dict}" target="_blank" rel="noopener">국어사전<small>네이버</small></a>
              <a class="lk-btn" data-lk="stdict" href="${u.stdict}" target="_blank" rel="noopener">표준국어대사전<small>국립국어원</small></a>
              <a class="lk-btn" data-lk="naver" href="${u.naver}" target="_blank" rel="noopener">통합 검색<small>네이버</small></a>
              <a class="lk-btn" data-lk="wiki" href="${u.wiki}" target="_blank" rel="noopener">위키백과<small>전체 문서</small></a>
            </div>
          </section>
          ${markInfo}
        </div>`, { label: `${text} 찾아보기` });
      this.wiki(q);
    },
    setQuery(q) {
      const u = this.urls(q);
      $$('.lk-btn[data-lk]').forEach((a) => { a.href = u[a.dataset.lk]; });
      this.wiki(q);
    },
    async wiki(q) {
      const tok = ++this.tok;
      const el = document.getElementById('lk-wiki'); if (!el) return;
      const head = '<h3 class="mini-h">위키백과 요약</h3>';
      if (PREVIEW) { el.innerHTML = `${head}<p class="muted">미리보기 화면에서는 바깥 검색을 불러올 수 없어요. Netlify에 올린 앱에서는 여기에 요약이 바로 떠요. 아래 버튼으로 사전을 열어 볼 수 있어요.</p>`; return; }
      el.innerHTML = `${head}<p class="muted">불러오는 중…</p>`;
      const url = `https://ko.wikipedia.org/w/api.php?action=query&format=json&origin=*&redirects=1&generator=search&gsrsearch=${encodeURIComponent(q)}&gsrlimit=1&prop=extracts%7Cinfo&exintro=1&explaintext=1&exchars=280&inprop=url`;
      try {
        const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 8000);
        const r = await fetch(url, { signal: ctl.signal }); clearTimeout(tm);
        const j = await r.json();
        if (tok !== this.tok || !document.getElementById('lk-wiki')) return;
        const pages = j && j.query && j.query.pages; const p = pages && Object.values(pages)[0];
        if (!p || !p.extract) { el.innerHTML = `${head}<p class="muted">딱 맞는 문서를 찾지 못했어요. 검색어를 줄이거나 아래 사전을 눌러 보세요.</p>`; return; }
        el.innerHTML = `${head}<p class="lk-wiki-title">${esc(p.title)}</p><p>${esc(p.extract)}</p><a class="link" href="${esc(p.fullurl || `https://ko.wikipedia.org/wiki/${encodeURIComponent(p.title)}`)}" target="_blank" rel="noopener">위키백과에서 전체 보기 ${icon('ext')}</a>`;
      } catch (e) {
        if (tok !== this.tok) return;
        const el2 = document.getElementById('lk-wiki');
        if (el2) el2.innerHTML = `${head}<p class="muted">요약을 불러오지 못했어요. 인터넷 연결을 확인하거나 아래 버튼으로 찾아보세요.</p>`;
      }
    },
  };

  // ---------------------------------------------------------------- 시트·토스트
  let sheetClose = null; let lastFocus = null;
  function openSheet(html, opt = {}) {
    const sheet = document.getElementById('sheet'); const scrim = document.getElementById('scrim');
    sheet.querySelector('.sheet-body').innerHTML = html;
    sheet.setAttribute('aria-label', opt.label || '자세히 보기');
    sheet.hidden = false; scrim.hidden = false;
    sheet.style.transform = '';
    requestAnimationFrame(() => { sheet.classList.add('open'); scrim.classList.add('open'); });
    document.body.classList.add('sheet-open');
    sheet.querySelector('.sheet-body').scrollTop = 0;
    lastFocus = document.activeElement;
    sheet.focus({ preventScroll: true });
    sheetClose = opt.onClose || null;
    applyMarks(sheet);
  }
  function closeSheet(instant) {
    const sheet = document.getElementById('sheet'); const scrim = document.getElementById('scrim');
    if (!sheet || sheet.hidden) return;
    sheet.classList.remove('open'); scrim.classList.remove('open');
    document.body.classList.remove('sheet-open');
    const done = () => { sheet.hidden = true; scrim.hidden = true; sheet.querySelector('.sheet-body').innerHTML = ''; };
    if (instant || reduceMotion()) done(); else setTimeout(done, 260);
    const cb = sheetClose; sheetClose = null; if (cb) cb();
    if (lastFocus && document.contains(lastFocus)) { try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* 무시 */ } }
  }
  function initSheetDrag() {
    const sheet = document.getElementById('sheet'); const grab = sheet.querySelector('.sheet-grab');
    let y0 = null; let dy = 0;
    grab.addEventListener('touchstart', (e) => { y0 = e.touches[0].clientY; dy = 0; sheet.style.transition = 'none'; }, { passive: true });
    grab.addEventListener('touchmove', (e) => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); sheet.style.transform = `translateY(${dy}px)`; }, { passive: true });
    grab.addEventListener('touchend', () => { sheet.style.transition = ''; if (dy > 90) closeSheet(); else sheet.style.transform = ''; y0 = null; });
  }
  let toastTimer = 0;
  function toast(msg, opt = {}) {
    const el = document.getElementById('toast'); if (!el) return;
    el.innerHTML = `<span>${esc(msg)}</span>${opt.action ? `<button data-act="toast-action">${esc(opt.action)}</button>` : ''}`;
    el.hidden = false; el._action = opt.onAction || null;
    requestAnimationFrame(() => el.classList.add('show'));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.classList.remove('show'); setTimeout(() => { el.hidden = true; }, 220); }, opt.ms || 2200);
  }
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); toast('복사했어요'); } catch (e) { toast('복사하지 못했어요. 길게 눌러 직접 복사해 주세요'); }
  }
  async function shareText(title, text) {
    if (navigator.share) { try { await navigator.share({ title, text }); return; } catch (e) { if (e && e.name === 'AbortError') return; } }
    copyText(`${title}\n${text}`);
  }

  // ---------------------------------------------------------------- 화면: 공통
  const ui = { learnTab: 'proverb', pageIdx: {}, archFilter: 'all', likeFilter: 'all', clearArm: 0, subFilter: {} };
  function topBar(title, actions = '') {
    return `<div class="topbar"><button class="icon-btn" data-act="back" aria-label="뒤로">${icon('chev-l')}</button><div class="topbar-title">${esc(title)}</div><div class="topbar-act">${actions}</div></div>`;
  }
  function greeting(h) {
    if (h < 5) return '늦은 밤이에요. 조금만 보고 쉬어요.';
    if (h < 10) return '좋은 아침이에요. 출근길 한 장 넘겨 볼까요?';
    if (h < 12) return '오전도 힘내요.';
    if (h < 14) return '점심은 맛있게 드셨어요?';
    if (h < 17) return '오후에 잠깐 쉬어 가요.';
    if (h < 21) return '퇴근길, 오늘도 수고 많았어요.';
    return '오늘 하루도 고생했어요.';
  }
  const dowClass = (k) => { const hi = holidayInfo(k); return dow(k) === 0 || (hi && hi.today) ? 'sun' : dow(k) === 6 ? 'sat' : ''; };
  function holidayText(today) {
    const hi = holidayInfo(today); if (!hi) return '';
    if (hi.today) return `오늘은 ${hi.name}`;
    return `다음 휴일 ${dateLabel(hi.k)} ${hi.name} (D-${hi.dday})`;
  }

  // ---------------------------------------------------------------- 화면: 홈
  function vHome() {
    const { key: today, hour } = nowKST();
    const { m, d } = md(today); const L = lunarOf(today); const g = ganji(today);
    DAILY_CATS.forEach((c) => Daily.ensure(c.key, today));
    const hidden = new Set(S.settings.hide || []);
    const order = ['politics', 'assembly', 'economy', 'stock', 'society', 'world', 'policy', 'tech', 'sports', 'entertainment', 'culture', 'fashion', 'events'];
    const hot = D.arts.filter((a) => a.hot && !hidden.has(a.cat) && order.includes(a.cat)).sort((a, b) => order.indexOf(a.cat) - order.indexOf(b.cat)).slice(0, 6);
    const cats = NEWS_CATS.filter((c) => !hidden.has(c.key));
    return `
      <header class="home-head">
        <div class="head-row">
          <div>
            <p class="greet">${greeting(hour)}</p>
            <h1 class="date-title">${m}월 ${d}일 <span class="dow ${dowClass(today)}">${DOW[dow(today)]}요일</span></h1>
            <p class="date-sub">${L ? `음력 ${L.m}월 ${L.d}일 · ` : ''}${ganjiK(g)}일${holidayText(today) ? ` · ${holidayText(today)}` : ''}</p>
          </div>
          <button class="icon-btn" data-act="go" data-to="settings" aria-label="설정">${icon('sliders')}</button>
        </div>
      </header>
      <section class="wx card" id="wx" aria-live="polite">${Weather.skeleton()}</section>
      <section class="block">
        <div class="block-head"><h2>오늘의 한 장</h2><a class="link" href="#learn">넘겨 보기 ${icon('chev-r')}</a></div>
        ${homeIlryeok(today)}
      </section>
      <section class="block">
        <div class="block-head"><h2>오늘의 이슈</h2><span class="muted small">${editionLabel()}</span></div>
        <div class="card list">${hot.map(issueRow).join('') || '<p class="empty-sm">표시할 이슈가 없어요.</p>'}</div>
      </section>
      <section class="block">
        <div class="block-head"><h2>분야별로 보기</h2><a class="link" href="#settings">분야 편집</a></div>
        <div class="cat-grid">${cats.map(catTile).join('')}</div>
      </section>
      <p class="foot-note">시험판 v${VERSION} · 뉴스는 ${editionLabel()}으로 정리했고, 기사마다 출처를 달았어요.</p>`;
  }
  function homeIlryeok(today) {
    const { m, d } = md(today); const L = lunarOf(today); const g = ganji(today);
    const rows = DAILY_CATS.map((c) => {
      const e = Daily.entries(c.key, today)[0]; const it = e && Daily.item(c.key, e.id);
      if (!it) return '';
      return `<li><button class="ilr-row" data-act="learn-open" data-cat="${c.key}"><span class="ilr-k" style="--c:${c.color}">${c.label}</span><span class="ilr-v">${esc(cardHead(c.key, it)[0])}</span>${icon('chev-r', 'ilr-go')}</button></li>`;
    }).join('');
    const z = S.settings.zodiac;
    const fRow = z == null
      ? `<li><button class="ilr-row" data-act="learn-open" data-cat="fortune"><span class="ilr-k" style="--c:${FORTUNE_TAB.color}">운세</span><span class="ilr-v muted">내 띠를 고르면 오늘 운세를 볼 수 있어요</span>${icon('chev-r', 'ilr-go')}</button></li>`
      : `<li><button class="ilr-row" data-act="learn-open" data-cat="fortune"><span class="ilr-k" style="--c:${FORTUNE_TAB.color}">운세</span><span class="ilr-v">${ZODIAC[z]}띠 ${stars(fortune(today, z).areas[0].sc)}</span>${icon('chev-r', 'ilr-go')}</button></li>`;
    return `
      <div class="ilr">
        <div class="ilr-binding" aria-hidden="true"><i></i><i></i></div>
        <div class="ilr-page">
          <div class="ilr-date ${dowClass(today)}">
            <span class="ilr-month">${m}월</span>
            <span class="ilr-num">${d}</span>
            <span class="ilr-dow">${DOW[dow(today)]}요일</span>
            <span class="ilr-lunar">${L ? `음 ${L.m}.${L.d}` : ''}<br>${ganjiK(g)}일</span>
          </div>
          <ul class="ilr-list">${rows}${fRow}</ul>
        </div>
      </div>`;
  }
  function issueRow(a) {
    const c = newsCat(a.cat);
    return `<a class="issue" href="#a-${esc(a.id)}"><span class="issue-main"><span class="tag" style="--c:${c.color}">${c.label}</span><span class="issue-title">${esc(a.title)}</span></span>${icon('chev-r', 'issue-go')}</a>`;
  }
  function catTile(c) {
    const list = D.arts.filter((a) => a.cat === c.key);
    const unread = list.filter((a) => !S.read[a.id]).length;
    const label = !list.length ? '준비 중' : c.reading ? `읽을거리 ${list.length}편` : unread ? `새 기사 ${unread}` : `${list.length}건 모두 읽음`;
    return `<a class="cat-tile" href="#news-${c.key}" style="--c:${c.color}"><span class="cat-ico">${icon('cat-' + c.key)}</span><span class="cat-name">${c.label}</span><span class="cat-count">${label}</span></a>`;
  }

  // ---------------------------------------------------------------- 화면: 분야별 뉴스
  // 행사 날짜 → 진행 중 / D-n / 끝남
  function whenInfo(w) {
    if (!w || !w.start) return null;
    const today = nowKST().key; const s = w.start; const e = w.end || w.start;
    const range = s === e ? dateLabel(s) : `${dateLabel(s)} ~ ${dateLabel(e)}`;
    if (today > e) return { range, state: 'ended', label: '끝났어요' };
    if (today >= s) return { range, state: 'live', label: e === today ? '오늘 마지막 날' : '진행 중' };
    const d = diffDays(s, today);
    return { range, state: 'soon', label: d === 0 ? '오늘 시작' : `D-${d}` };
  }
  function eventSort(a, b) {
    const rank = (x) => { const w = whenInfo(x.when); return !w ? 3 : w.state === 'live' ? 0 : w.state === 'soon' ? 1 : 2; };
    return rank(a) - rank(b) || String((a.when || {}).start || '').localeCompare(String((b.when || {}).start || ''));
  }
  function factsHtml(a) {
    const rows = (a.facts || []).filter((f) => f && f.k && f.v);
    const w = a.cat === 'events' ? whenInfo(a.when) : null;
    if (!rows.length && !w) return '';
    return `<dl class="facts">${w ? `<dt>상태</dt><dd><span class="when-badge when-${w.state}">${esc(w.label)}</span> ${esc(w.range)}</dd>` : ''}${rows.map((f) => `<dt>${esc(f.k)}</dt><dd>${safeUrl(f.url) ? `<a href="${esc(safeUrl(f.url))}" target="_blank" rel="noopener">${esc(f.v)}${icon('ext')}</a>` : esc(f.v)}</dd>`).join('')}</dl>`;
  }
  function vNews(key) {
    const c = newsCat(key); if (!c) return vMissing();
    const all = D.arts.filter((a) => a.cat === key);
    const known = c.subs || [];
    const present = known.filter((s) => all.some((a) => a.sub === s)).concat([...new Set(all.map((a) => a.sub).filter((s) => s && !known.includes(s)))]);
    let f = ui.subFilter[key];
    if (c.tabs) { if (!f || !present.includes(f)) f = present[0] || ''; }
    else if (!f || (f !== '전체' && !present.includes(f))) f = '전체';
    ui.subFilter[key] = f;
    const list = f && f !== '전체' ? all.filter((a) => a.sub === f) : all.slice();
    if (key === 'events') list.sort(eventSort);
    else list.sort((a, b) => (b.hot ? 1 : 0) - (a.hot ? 1 : 0) || String(b.date).localeCompare(String(a.date)));
    let chips = '';
    if (c.tabs && present.length) chips = `<nav class="seg sub-tabs" role="tablist" aria-label="${esc(c.label)} 세부">${present.map((s) => `<button role="tab" class="seg-btn ${s === f ? 'on' : ''}" aria-selected="${s === f}" data-act="sub-filter" data-cat="${key}" data-f="${esc(s)}">${esc(s)}</button>`).join('')}</nav>`;
    else if (present.length > 1) chips = `<div class="chips filter">${['전체', ...present].map((s) => `<button class="chip-btn ${s === f ? 'on' : ''}" data-act="sub-filter" data-cat="${key}" data-f="${esc(s)}">${esc(s)} ${s === '전체' ? all.length : all.filter((a) => a.sub === s).length}</button>`).join('')}</div>`;
    const info = c.reading ? `오래 두고 읽는 글 ${all.length}편` : `${editionLabel()} · ${all.length}건`;
    return `
      ${topBar(c.label)}
      <header class="page-head">
        <p class="eyebrow cat-eyebrow" style="--c:${c.color}">${icon('cat-' + c.key)}<span>${c.desc}</span></p>
        <h1 class="page-title">${c.label}</h1>
        <p class="muted small">${info}</p>
      </header>
      ${c.note ? `<p class="cat-note">${esc(c.note)}</p>` : ''}
      ${chips}
      ${list.length ? `<div class="art-list">${list.map((a) => artCard(a, { hideSub: f && f !== '전체' })).join('')}</div>` : emptyBox('cat-' + key, '아직 새 소식이 없어요', '다음 업데이트 때 채워져요. 조사해도 기사가 없는 날은 비어 있을 수 있어요.', '#home', '홈으로')}`;
  }
  function artCard(a, opt = {}) {
    const c = newsCat(a.cat) || {};
    const read = !!S.read[a.id]; const liked = !!S.likes[likeKeyArt(a.id)];
    const w = a.cat === 'events' ? whenInfo(a.when) : null;
    const meta = [];
    if (a.hot) meta.push('<span class="pill">핵심</span>');
    if (a.sub && !opt.hideSub) meta.push(`<span class="meta-sub">${esc(a.sub)}</span>`);
    if (w) meta.push(`<span class="when-badge when-${w.state}">${esc(w.label)}</span><span>${esc(w.range)}</span>`);
    else if (c.reading) { if (a.era) meta.push(`<span>${esc(a.era)}</span>`); }
    else meta.push(`<span>${dateDow(a.date)}</span>`);
    if (!w) meta.push(`<span>${a.readMin}분</span>`);
    if (read) meta.push('<span>읽음</span>');
    if (liked) meta.push(icon('heart-fill', 'meta-like'));
    return `<a class="art-card card ${read ? 'is-read' : ''}" href="#a-${esc(a.id)}" style="--c:${c.color || '#888888'}">
      <div class="art-meta">${meta.join('')}</div>
      <h2 class="art-title">${esc(a.title)}</h2>
      <p class="art-dek">${esc(a.dek)}</p>
      ${c.reading && a.place ? `<p class="art-place">${icon('pin')}<span>${esc(a.place)}</span></p>` : ''}
    </a>`;
  }

  // ---------------------------------------------------------------- 화면: 기사
  function linkTerms(text, gl, seen) {
    const ranges = [];
    const order = gl.map((g, i) => ({ t: g.term, i })).sort((a, b) => b.t.length - a.t.length);
    for (const { t, i } of order) {
      if (!t || seen.has(i)) continue;
      let from = 0; let idx;
      while ((idx = text.indexOf(t, from)) !== -1) {
        const end = idx + t.length;
        if (!ranges.some((r) => idx < r.e && end > r.s)) { ranges.push({ s: idx, e: end, i }); seen.add(i); break; }
        from = idx + 1;
      }
    }
    ranges.sort((a, b) => a.s - b.s);
    let out = ''; let pos = 0;
    for (const r of ranges) { out += esc(text.slice(pos, r.s)) + `<span class="term" role="button" tabindex="0" data-gi="${r.i}">${esc(text.slice(r.s, r.e))}</span>`; pos = r.e; }
    return out + esc(text.slice(pos));
  }
  function vArticle(id) {
    const a = artById(id); if (!a) return vMissing();
    const c = newsCat(a.cat) || NEWS_CATS[0];
    const past = isPastArt(id);
    if (!S.read[id]) { S.read[id] = Date.now(); save(); }
    keepArt(a);
    const liked = !!S.likes[likeKeyArt(id)];
    const gl = a.glossary || [];
    const seen = new Set(); let pid = 0;
    const body = (a.sections || []).map((sec) => {
      let h = `<h2 class="sec-h">${esc(sec.h)}</h2>`;
      h += (sec.p || []).map((p) => `<p data-pid="${pid++}">${linkTerms(p, gl, seen)}</p>`).join('');
      if (sec.ol && sec.ol.length) h += `<ol>${sec.ol.map((x) => `<li data-pid="${pid++}">${linkTerms(x, gl, seen)}</li>`).join('')}</ol>`;
      if (sec.li && sec.li.length) h += `<ul>${sec.li.map((x) => `<li data-pid="${pid++}">${linkTerms(x, gl, seen)}</li>`).join('')}</ul>`;
      return h;
    }).join('');
    const sib = D.arts.filter((x) => x.cat === a.cat && x.id !== id && (!c.tabs || x.sub === a.sub)).slice(0, 4);
    const eyebrow = c.reading ? `${c.label} · ${a.sub || ''}${a.era ? ` · ${a.era}` : ''}` : `${c.label}${a.sub ? ` · ${a.sub}` : ''} · ${dateDow(a.date)}`;
    const stops = Math.max(1, Math.round((a.readMin || 2) / 2));
    const showTip = (S.settings.tip || 0) < 99;
    return `
      ${topBar(c.label, `<button class="icon-btn fs-btn" data-act="fs" aria-label="글자 크기 바꾸기">가<small>가</small></button><button class="icon-btn like-top ${liked ? 'on' : ''}" data-act="like-art" data-id="${esc(id)}" aria-pressed="${liked}" aria-label="좋아요">${icon(liked ? 'heart-fill' : 'heart')}</button>`)}
      <article class="article">
        <p class="eyebrow cat-eyebrow" style="--c:${c.color}">${icon('cat-' + c.key)}<span>${esc(eyebrow)}</span></p>
        <h1 class="art-h1">${esc(a.title)}</h1>
        <p class="art-lede">${esc(a.dek)}</p>
        ${past ? `<p class="past-note">${icon('archive')}<span>지난 기사예요. 읽은 기사라 이 기기에 보관해 둔 사본을 보여 드려요.</span></p>` : ''}
        <p class="art-info">${a.readMin}분 읽기 · 지하철 약 ${stops}정거장 · 출처 ${(a.sources || []).length}곳${a.place && !(a.facts || []).some((x) => /위치|장소|주소/.test(x.k || '')) ? ` · ${esc(a.place)}` : ''}</p>
        ${factsHtml(a)}
        ${showTip ? `<div class="tip-box">${icon('marker')}<p>모르는 말은 <b>길게 눌러 선택</b>해 보세요. 형광펜이 칠해지고 바로 뜻을 찾아 줘요. 점선 밑줄 말은 눌러서 풀이를 볼 수 있어요.</p><button class="btn-ghost sm" data-act="tip-ok">알겠어요</button></div>` : ''}
        <section class="summary3" aria-label="3줄 요약"><h2 class="mini-h"><span class="hl-text">3줄 요약</span></h2><ul>${(a.summary3 || []).map((s) => `<li>${esc(s)}</li>`).join('')}</ul></section>
        <div class="readable art-body" data-doc="a:${esc(id)}">${body}</div>
        ${a.why ? `<section class="why"><h2 class="mini-h">${esc(c.whyLabel || '나랑 무슨 상관?')}</h2><p>${esc(a.why)}</p></section>` : ''}
        ${c.note ? `<p class="cat-note">${esc(c.note)}</p>` : ''}
        ${gl.length ? `<section class="gloss" id="gloss"><h2 class="sec-h">용어 풀이</h2><p class="muted small">눌러서 쉬운 설명을 펼쳐 보세요.</p>${gl.map(glossItem).join('')}</section>` : ''}
        <section class="sources"><h2 class="mini-h">출처</h2><ul>${(a.sources || []).filter((s) => safeUrl(s.url)).map((s) => `<li class="src"><a href="${esc(safeUrl(s.url))}" target="_blank" rel="noopener"><span class="src-name">${esc(s.name)} · ${esc(s.date || '')}</span><span class="src-title">${esc(s.title)}</span></a></li>`).join('')}</ul></section>
        <div class="art-actions">${likeBtn(liked, 'like-art', `data-id="${esc(id)}"`)}<button class="btn-ghost" data-act="share-art" data-id="${esc(id)}">${icon('share')} 공유</button></div>
        ${sib.length ? `<section class="next"><h2 class="mini-h">${c.tabs ? esc(a.sub) : c.label} 다른 ${c.reading ? '글' : '기사'}</h2><div class="art-list">${sib.map((x) => artCard(x, { hideSub: !!c.tabs })).join('')}</div></section>` : ''}
      </article>`;
  }
  function glossItem(g, i) {
    return `<details class="gl-item" id="gl-${i}"><summary><span class="gl-term">${esc(g.term)}</span><span class="gl-short">${esc(g.short)}</span>${icon('chev-d', 'gl-chev')}</summary><div class="gl-body"><p>${esc(g.long)}</p><button class="btn-ghost sm" data-act="lookup" data-q="${esc(g.term)}">${icon('search')} 더 찾아보기</button></div></details>`;
  }

  // ---------------------------------------------------------------- 화면: 오늘의 한 장
  function vLearn(focus) {
    const today = nowKST().key;
    DAILY_CATS.forEach((c) => Daily.ensure(c.key, today));
    if (focus && dailyCat(focus)) ui.learnTab = focus;
    const tab = ui.learnTab;
    const tabs = [...DAILY_CATS, FORTUNE_TAB];
    return `
      <header class="page-head">
        <h1 class="page-title">오늘의 한 장</h1>
        <p class="muted small">${dateLabel(today)} ${DOW[dow(today)]}요일 · 하루 한 장씩, 틈틈이 넘겨 봐요</p>
      </header>
      <nav class="seg" role="tablist" aria-label="분야">${tabs.map((c) => `<button role="tab" class="seg-btn ${c.key === tab ? 'on' : ''}" aria-selected="${c.key === tab}" data-act="learn-tab" data-cat="${c.key}" style="--c:${c.color}">${c.label}</button>`).join('')}</nav>
      <div id="learn-pane">${learnPane(tab, today)}</div>
      <div id="review-wrap">${reviewHtml(today)}</div>
      ${algoHtml()}`;
  }
  function pageHeader(today, cat, idx, total) {
    const { m, d } = md(today); const L = lunarOf(today); const g = ganji(today);
    return `<div class="page-date ${dowClass(today)}">
      <span class="pd-num">${d}</span>
      <div class="pd-info"><b>${m}월 · ${DOW[dow(today)]}요일</b><span>${L ? `${L.yearName ? L.yearName + '년 ' : ''}음력 ${L.m}월 ${L.d}일 · ` : ''}${ganjiK(g)}일</span></div>
      ${total > 1 ? `<div class="pd-pager"><button class="icon-btn" data-act="page" data-dir="-1" ${idx === 0 ? 'disabled' : ''} aria-label="이전 장">${icon('chev-l')}</button><span>${idx + 1} / ${total}장</span><button class="icon-btn" data-act="page" data-dir="1" ${idx === total - 1 ? 'disabled' : ''} aria-label="다음 장">${icon('chev-r')}</button></div>` : total ? '<span class="pd-count">오늘의 첫 장</span>' : ''}
    </div>`;
  }
  function learnPane(cat, today) {
    if (cat === 'fortune') return `<div class="ilr ilr-big"><div class="ilr-binding" aria-hidden="true"><i></i><i></i></div><article class="card-page" id="card-page">${pageHeader(today, cat, 0, 0)}${fortuneHtml(today)}</article></div>`;
    const picks = Daily.entries(cat, today);
    if (!picks.length) return '<p class="empty">카드를 불러오지 못했어요.</p>';
    const idx = clamp(ui.pageIdx[cat] == null ? picks.length - 1 : ui.pageIdx[cat], 0, picks.length - 1);
    const e = picks[idx]; const it = Daily.item(cat, e.id);
    const liked = !!S.likes[likeKeyCard(cat, e.id)];
    const remain = Daily.remaining(cat);
    return `
      <div class="ilr ilr-big">
        <div class="ilr-binding" aria-hidden="true"><i></i><i></i></div>
        <article class="card-page" id="card-page" data-cat="${cat}">${pageHeader(today, cat, idx, picks.length)}<div class="card-body">${cardBody(cat, it)}</div></article>
      </div>
      <div class="card-actions">
        ${likeBtn(liked, 'like-card', `data-cat="${cat}" data-id="${esc(e.id)}"`)}
        <button class="btn-ghost icon-only" data-act="share-card" data-cat="${cat}" data-id="${esc(e.id)}" aria-label="공유">${icon('share')}</button>
        <button class="btn-primary" data-act="more" data-cat="${cat}">${icon('plus')} 한 장 더</button>
      </div>
      <p class="muted small center">아직 안 넘긴 ${dailyCat(cat).label} 카드 ${remain}장 · 넘긴 카드는 보관함에 모여요</p>`;
  }
  function fortuneHtml(today) {
    const g = ganji(today); const z = S.settings.zodiac;
    const head = `<div class="ilgin"><span class="ilgin-hj" lang="ko">${ganjiH(g)}日</span><div><b>오늘의 일진 · ${ganjiK(g)}일</b><span>${STEM_COLOR[g.s]} ${ZODIAC[g.b]}의 날 · ${EL_INFO[STEM_EL[g.s]].name}의 기운</span></div></div>`;
    const pickGrid = `<div class="z-grid">${ZODIAC.map((n, i) => `<button class="z-btn ${z === i ? 'on' : ''}" data-act="set-zodiac" data-z="${i}"><span>${n}</span><small>${BR_H[i]}</small></button>`).join('')}</div>`;
    if (z == null) {
      const rows = ZODIAC.map((n, i) => { const f = fortune(today, i); return `<li><span class="z-name">${n}띠</span>${stars(f.areas[0].sc)}<span class="z-rel">${f.rel.label}</span></li>`; }).join('');
      return `${head}<p class="f-lead">내 띠를 고르면 오늘의 운세를 자세히 보여 드려요.</p>${pickGrid}<h3 class="mini-h">띠별 한눈에 보기</h3><ul class="z-list">${rows}</ul><p class="muted small f-note">일진과 띠의 합·충을 바탕으로 만든 재미로 보는 운세예요.</p>`;
    }
    const f = fortune(today, z);
    return `${head}
      <div class="f-rel"><span class="badge f-${f.rel.key}">${ZODIAC[z]}띠 · ${f.rel.label}</span><p>${f.rel.desc}</p></div>
      <ul class="f-areas">${f.areas.map((a) => `<li><span class="f-name">${a.name}</span>${stars(a.sc)}<p>${a.msg}</p></li>`).join('')}</ul>
      <div class="f-lucky"><div><span>행운의 색</span><b>${f.el.color}</b></div><div><span>행운의 숫자</span><b>${f.el.nums}</b></div><div><span>행운의 방향</span><b>${f.el.dir}</b></div></div>
      <p class="f-tip">${icon('bulb')}<span>${f.tip}</span></p>
      <details class="f-change"><summary>띠 바꾸기</summary>${pickGrid}</details>
      <p class="muted small f-note">일진(${ganjiK(f.g)}일)과 ${ZODIAC[z]}띠의 합·충을 바탕으로 만든 재미로 보는 운세예요.</p>`;
  }
  function reviewFaces(cat, it) {
    switch (cat) {
      case 'proverb': return { q: esc(it.text), a: esc(it.meaning) };
      case 'idiom': return { q: `<span class="hanja">${esc(it.hanja)}</span><span class="muted"> 읽는 법과 뜻은?</span>`, a: `<b>${esc(it.word)}</b> · ${esc(it.meaning)}` };
      case 'trivia': case 'origin': return { q: esc(it.title), a: esc(it.answer) };
      case 'word':
        if (it.kind === '순우리말') return { q: `<b>${esc(it.right)}</b>의 뜻은?`, a: esc(it.meaning) };
        if (it.wrong) { const pair = hashStr(it.id) % 2 ? [it.right, it.wrong] : [it.wrong, it.right]; return { q: `<b>${esc(pair[0])}</b> / <b>${esc(pair[1])}</b> 어느 쪽이 맞을까요?`, a: `<b>${esc(it.right)}</b> · ${esc(it.tip || '')}` }; }
        return { q: `<b>${esc(it.title)}</b> 어떻게 가려 쓸까요?`, a: `${esc(it.right)} · ${esc(it.tip || '')}` };
      default: return { q: '', a: '' };
    }
  }
  function reviewHtml(today) {
    const list = Daily.reviewList(today);
    if (!list.length) return '';
    return `<section class="block">
      <div class="block-head"><h2>기억나요?</h2><span class="muted small">복습 ${list.length}장</span></div>
      <div class="flip-list">${list.map((h) => { const it = Daily.item(h.c, h.id); const f = reviewFaces(h.c, it); const c = dailyCat(h.c); return `
        <div class="flip card" data-key="${h.c}:${esc(h.id)}">
          <button class="flip-front" data-act="flip" aria-expanded="false"><span class="flip-meta"><span class="tag" style="--c:${c.color}">${c.label}</span>${h.age}일 전에 넘긴 카드</span><span class="flip-q">${f.q}</span><span class="flip-hint">눌러서 답 보기</span></button>
          <div class="flip-back" hidden><p class="flip-a">${f.a}</p><div class="flip-btns"><button class="btn-ghost sm" data-act="rv" data-ok="1">${icon('check')} 기억나요</button><button class="btn-ghost sm" data-act="rv" data-ok="0">헷갈려요 · 내일 다시</button><button class="btn-ghost sm" data-act="open-card" data-cat="${h.c}" data-id="${esc(h.id)}" data-d="${h.d}">카드 보기</button></div></div>
        </div>`; }).join('')}</div>
    </section>`;
  }
  function algoHtml() {
    const rem = DAILY_CATS.map((c) => `${c.label} ${Daily.remaining(c.key)}`).join(' · ');
    return `<details class="algo card">
      <summary>${icon('bulb')}<span>오늘의 한 장은 이렇게 골라요</span>${icon('chev-d', 'gl-chev')}</summary>
      <ol>
        <li>아직 안 넘긴 카드 중에서만 골라요. 한 바퀴를 다 돌면 다시 섞어 새 바퀴를 시작해요.</li>
        <li>날짜를 씨앗 삼아 섞기 때문에 하루 동안은 몇 번을 열어도 같은 카드가 나와요.</li>
        <li>처음 열 장은 쉬운 카드 위주로, 그 뒤로는 어려운 카드도 고르게 섞어요.</li>
        <li>좋아요를 누른 카드와 같은 주제는 조금 더 자주, 바로 앞 카드와 같은 주제는 조금 덜 나와요.</li>
        <li>1·3·7·14·30일 전에 넘긴 카드는 '기억나요?'에서 다시 보여 줘요. '헷갈려요'를 누르면 다음 날 또 나와요.</li>
        <li>매일 자정(한국 시간)이 지나면 새 카드가 준비돼요.</li>
        <li>한 분야 카드를 다 넘기면 처음부터 다시 섞어 복습 겸 다시 보여 줘요. 새 카드는 업데이트 때 더해져요.</li>
      </ol>
      <p class="muted small">아직 안 넘긴 카드 — ${rem}</p>
    </details>`;
  }
  function openCardSheet(cat, id, d) {
    const it = Daily.item(cat, id); if (!it) return;
    const liked = !!S.likes[likeKeyCard(cat, id)];
    const when = d || (S.history.find((h) => h.c === cat && h.id === id) || {}).d;
    openSheet(`<div class="sheet-card">
      ${when ? `<p class="eyebrow">${dateDow(when)}에 넘긴 카드</p>` : ''}
      <div class="card-body">${cardBody(cat, it)}</div>
      <div class="card-actions">${likeBtn(liked, 'like-card', `data-cat="${cat}" data-id="${esc(id)}"`)}<button class="btn-ghost icon-only" data-act="share-card" data-cat="${cat}" data-id="${esc(id)}" aria-label="공유">${icon('share')}</button></div>
    </div>`, { label: cardHead(cat, it)[0] });
  }

  // ---------------------------------------------------------------- 화면: 보관함
  function vArchive(mode) {
    const tab = mode === 'read' ? 'read' : 'cards';
    const seg = `<nav class="seg seg-2" role="tablist"><a role="tab" class="seg-btn ${tab === 'cards' ? 'on' : ''}" href="#archive" aria-selected="${tab === 'cards'}">넘긴 카드</a><a role="tab" class="seg-btn ${tab === 'read' ? 'on' : ''}" href="#archive-read" aria-selected="${tab === 'read'}">읽은 기사</a></nav>`;
    if (tab === 'read') {
      const list = Object.entries(S.read).map(([id, t]) => ({ a: artById(id), t })).filter((x) => x.a && newsCat(x.a.cat)).sort((x, y) => y.t - x.t);
      return `<header class="page-head"><h1 class="page-title">보관함</h1><p class="muted small">읽은 기사 ${list.length}건</p></header>${seg}
        ${list.length ? `<div class="card list">${list.map(({ a }) => { const c = newsCat(a.cat); return `<a class="row" href="#a-${esc(a.id)}"><span class="tag" style="--c:${c.color}">${c.label}</span><span class="row-main"><b>${esc(a.title)}</b><small>${dateDow(a.date)}</small></span>${S.likes[likeKeyArt(a.id)] ? icon('heart-fill', 'row-like') : icon('chev-r', 'row-go')}</a>`; }).join('')}</div>` : emptyBox('archive', '아직 읽은 기사가 없어요', '홈에서 관심 분야를 눌러 기사를 읽어 보세요.', '#home', '홈으로')}`;
    }
    const f = ui.archFilter;
    const hist = S.history.filter((h) => f === 'all' || h.c === f).filter((h) => Daily.item(h.c, h.id));
    const byDate = new Map();
    for (let i = hist.length - 1; i >= 0; i--) { const h = hist[i]; if (!byDate.has(h.d)) byDate.set(h.d, []); byDate.get(h.d).push(h); }
    const dates = [...byDate.keys()].sort().reverse();
    const counts = DAILY_CATS.map((c) => S.history.filter((h) => h.c === c.key).length);
    const chips = `<div class="chips filter">${[{ key: 'all', label: '전체' }, ...DAILY_CATS].map((c) => `<button class="chip-btn ${f === c.key ? 'on' : ''}" data-act="arch-filter" data-f="${c.key}">${c.label}</button>`).join('')}</div>`;
    return `<header class="page-head"><h1 class="page-title">보관함</h1><p class="muted small">지금까지 넘긴 카드 ${S.history.length}장 · ${DAILY_CATS.map((c, i) => `${c.label} ${counts[i]}`).join(' · ')}</p></header>${seg}${chips}
      ${dates.length ? dates.map((d) => `<h2 class="date-h">${dateDow(d)}${diffDays(nowKST().key, d) === 0 ? ' · 오늘' : ''}</h2><div class="card list">${byDate.get(d).map(archRow).join('')}</div>`).join('') : emptyBox('page', '아직 보관된 카드가 없어요', '오늘의 한 장을 넘기면 여기 날짜별로 차곡차곡 쌓여요. 설정에서 체험용 지난 7일 기록을 만들어 볼 수도 있어요.', '#learn', '오늘의 한 장 보기')}`;
  }
  function archRow(h) {
    const it = Daily.item(h.c, h.id); const c = dailyCat(h.c); const [head, sub] = cardHead(h.c, it);
    return `<button class="row" data-act="open-card" data-cat="${h.c}" data-id="${esc(h.id)}" data-d="${h.d}"><span class="tag" style="--c:${c.color}">${c.label}</span><span class="row-main"><b>${esc(head)}</b><small>${esc(sub)}</small></span>${S.likes[likeKeyCard(h.c, h.id)] ? icon('heart-fill', 'row-like') : h.demo ? '<span class="demo-tag">체험</span>' : icon('chev-r', 'row-go')}</button>`;
  }
  function emptyBox(ic, title, text, href, btn) {
    return `<div class="empty">${icon(ic, 'empty-ico')}<h2>${title}</h2><p>${text}</p>${href ? `<a class="btn-ghost" href="${href}">${btn}</a>` : ''}</div>`;
  }

  // ---------------------------------------------------------------- 화면: 좋아요
  function vLikes() {
    const f = ui.likeFilter;
    const all = Object.entries(S.likes).map(([k, v]) => Object.assign({ k }, v)).sort((a, b) => b.t - a.t);
    const list = all.filter((x) => f === 'all' || (f === 'art' ? x.type === 'art' : x.type === 'card'));
    const chips = `<div class="chips filter">${[['all', '전체'], ['art', '기사'], ['card', '카드']].map(([k, l]) => `<button class="chip-btn ${f === k ? 'on' : ''}" data-act="like-filter" data-f="${k}">${l} ${k === 'all' ? all.length : all.filter((x) => (k === 'art' ? x.type === 'art' : x.type === 'card')).length}</button>`).join('')}</div>`;
    const row = (x) => {
      if (x.type === 'art') { const c = newsCat(x.cat) || { color: '#888', label: '기사' }; return `<a class="row" href="#a-${esc(x.id)}"><span class="tag" style="--c:${c.color}">${c.label}</span><span class="row-main"><b>${esc(x.head)}</b><small>${esc(x.sub)}</small></span>${icon('chev-r', 'row-go')}</a>`; }
      const c = dailyCat(x.cat) || { color: '#888', label: '카드' };
      return `<button class="row" data-act="open-card" data-cat="${x.cat}" data-id="${esc(x.id)}"><span class="tag" style="--c:${c.color}">${c.label}</span><span class="row-main"><b>${esc(x.head)}</b><small>${esc(x.sub)}</small></span>${icon('chev-r', 'row-go')}</button>`;
    };
    return `<header class="page-head"><h1 class="page-title">좋아요</h1><p class="muted small">마음에 든 기사와 카드를 모아 뒀어요</p></header>${chips}
      ${list.length ? `<div class="card list">${list.map(row).join('')}</div>` : emptyBox('heart', '아직 좋아요한 게 없어요', '기사나 카드에서 하트를 누르면 여기에 모여요. 좋아요한 카드와 비슷한 주제가 앞으로 조금 더 자주 나와요.', '#learn', '오늘의 한 장 보기')}`;
  }

  // ---------------------------------------------------------------- 화면: 단어장
  function vWords() {
    const list = S.words;
    return `<header class="page-head"><h1 class="page-title">단어장</h1><p class="muted small">형광펜으로 칠한 말 ${list.length}개</p></header>
      ${list.length ? `<div class="card list">${list.map((w, i) => `<div class="row word-row"><button class="row-main word-open" data-act="word-open" data-i="${i}"><b><span class="hl-text">${esc(w.t)}</span></b><small>${esc(docTitle(w.doc))} · ${dateLabel(fromUTC(w.at + 9 * 3600000))}</small></button><button class="icon-btn sm" data-act="word-del" data-i="${i}" aria-label="${esc(w.t)} 지우기">${icon('x')}</button></div>`).join('')}</div>`
        : emptyBox('marker', '아직 칠한 말이 없어요', '기사나 카드를 읽다가 모르는 말을 길게 눌러 선택해 보세요. 형광펜이 칠해지고 바로 뜻을 찾아 줘요. 칠한 말은 여기에 모여요.', '#home', '기사 읽으러 가기')}`;
  }

  // ---------------------------------------------------------------- 화면: 설정
  function vSettings() {
    const st = S.settings; const loc = Weather.loc();
    const fsBtns = ['작게', '보통', '크게'].map((l, i) => `<button class="seg-mini ${st.fs === i ? 'on' : ''}" data-act="set-fs" data-v="${i}">${l}</button>`).join('');
    const catRows = NEWS_CATS.map((c) => `<label class="set-row"><span class="set-cat" style="--c:${c.color}">${icon('cat-' + c.key)}${c.label}</span><input type="checkbox" class="switch" id="cat-${c.key}" data-act="toggle-cat" data-key="${c.key}" ${st.hide.includes(c.key) ? '' : 'checked'}></label>`).join('');
    const locOpts = LOCS.map((l, i) => `<option value="${i}" ${l.name === loc.name ? 'selected' : ''}>${l.name}</option>`).join('') + (st.loc && st.loc.name === '현재 위치' ? '<option value="here" selected>현재 위치</option>' : '');
    const demoCount = S.history.filter((h) => h.demo).length;
    return `${topBar('설정')}
      <header class="page-head"><h1 class="page-title">설정</h1></header>
      <h2 class="set-h">뉴스 업데이트</h2>
      <div class="card set-group">
        <div class="set-row"><span>지금 보는 뉴스<small>${editionLabel()} · ${((D.news && D.news.articles) || []).length}건</small></span><button class="btn-ghost sm" data-act="check-news">${icon('refresh')} 새 소식 확인</button></div>
        <p class="set-desc">뉴스는 조사해서 올린 파일을 받아 와요. 이 버튼은 새로 올라온 파일이 있는지 바로 확인해요. 앱을 다시 열 때도 30분이 지났으면 알아서 확인해요.</p>
      </div>
      <h2 class="set-h">읽기</h2>
      <div class="card set-group">
        <div class="set-row"><span>글자 크기</span><div class="seg-minis">${fsBtns}</div></div>
        <label class="set-row"><span>선택하면 바로 형광펜·찾기<small>끄면 선택한 뒤 버튼을 눌러 칠해요</small></span><input type="checkbox" class="switch" id="set-auto" data-act="toggle-auto" ${st.auto ? 'checked' : ''}></label>
      </div>
      <h2 class="set-h">홈에 보일 분야</h2>
      <div class="card set-group">${catRows}</div>
      <h2 class="set-h">날씨·운세</h2>
      <div class="card set-group">
        <label class="set-row" for="set-loc"><span>날씨 지역</span><select id="set-loc" class="select" data-act="set-loc">${locOpts}</select></label>
        <div class="set-row"><span>현재 위치로 날씨 보기<small>위치 권한을 물어봐요</small></span><button class="btn-ghost sm" data-act="use-geo">${icon('pin')} 사용</button></div>
        <label class="set-row" for="set-z"><span>내 띠</span><select id="set-z" class="select" data-act="set-z"><option value="">고르지 않음</option>${ZODIAC.map((n, i) => `<option value="${i}" ${st.zodiac === i ? 'selected' : ''}>${n}띠</option>`).join('')}</select></label>
      </div>
      <h2 class="set-h">기록</h2>
      <div class="card set-group">
        <div class="set-row"><span>체험용 지난 7일 기록 만들기<small>보관함과 복습 카드를 바로 확인해 볼 수 있어요</small></span><button class="btn-ghost sm" data-act="demo">만들기</button></div>
        ${demoCount ? `<div class="set-row"><span>체험용 기록만 지우기<small>체험 카드 ${demoCount}장</small></span><button class="btn-ghost sm" data-act="demo-clear">지우기</button></div>` : ''}
        <div class="set-row"><span>백업 파일로 저장<small>${PREVIEW ? 'Netlify에 올린 앱에서 쓸 수 있어요' : '기록·좋아요·단어장을 파일로 내려받아요'}</small></span>${PREVIEW ? '' : '<button class="btn-ghost sm" data-act="export">저장</button>'}</div>
        <label class="set-row"><span>백업 불러오기<small>저장해 둔 파일로 되돌려요</small></span><span class="btn-ghost sm file-btn">파일 고르기<input type="file" id="import-file" accept="application/json,.json" data-act="import"></span></label>
        <div class="set-row"><span>모든 기록 지우기</span><button class="btn-ghost sm danger" data-act="clear-all">${ui.clearArm > Date.now() ? '한 번 더 누르면 지워져요' : '지우기'}</button></div>
      </div>
      ${storeOK ? '' : '<p class="warn-box">이 브라우저에서는 기록을 저장할 수 없어요. 앱을 닫으면 기록이 사라져요.</p>'}
      <h2 class="set-h">아이폰 홈 화면에 앱처럼 설치하기</h2>
      <div class="card set-note">
        <ol><li>사파리에서 이 페이지를 열어요.</li><li>아래쪽 공유 버튼(네모에 위쪽 화살표)을 눌러요.</li><li>'홈 화면에 추가'를 누르고 '추가'를 눌러요.</li></ol>
        <p class="muted small">홈 화면 아이콘으로 열면 주소창 없이 앱처럼 열리고, 인터넷이 약해도 받아 둔 카드와 기사를 볼 수 있어요.</p>
      </div>
      <p class="foot-note">틈틈이 시험판 v${VERSION} · 뉴스 ${editionLabel()} · 카드 ${DAILY_CATS.map((c) => `${c.label} ${(D.pools[c.key].items || []).length}`).join(' · ')}</p>`;
  }
  function vMissing() { return `${topBar('')}${emptyBox('search', '찾는 화면이 없어요', '주소가 바뀌었거나 지난 기사일 수 있어요.', '#home', '홈으로')}`; }

  // ---------------------------------------------------------------- 라우터
  const scrollPos = {};
  let stack = []; let cur = null; let lastY = 0; let backNav = false;
  const route = () => decodeURIComponent((location.hash || '').replace(/^#/, '')) || 'home';
  function go(r) { if (r === route()) { render(); return; } location.hash = r; }
  function back() { if (stack.length) { history.back(); } else { location.hash = 'home'; } }
  function onHash() {
    const r = route();
    if (cur !== null) {
      scrollPos[cur] = lastY;
      if (stack.length && stack[stack.length - 1] === r) { stack.pop(); backNav = true; } else { stack.push(cur); backNav = false; }
      if (stack.length > 40) stack = stack.slice(-40);
    }
    render();
  }
  function render() {
    const r = route(); cur = r;
    closeSheet(true); hideChip();
    const view = document.getElementById('view');
    let html; let tab = 'home'; let after = null;
    if (r === 'home') { html = vHome(); after = () => Weather.mount(); }
    else if (r.startsWith('news-')) html = vNews(r.slice(5));
    else if (r.startsWith('a-')) { html = vArticle(r.slice(2)); after = () => applyMarks(view); }
    else if (r === 'learn' || r.startsWith('learn-')) { html = vLearn(r.slice(6)); tab = 'learn'; after = () => applyMarks(view); }
    else if (r === 'archive' || r === 'archive-read') { html = vArchive(r === 'archive-read' ? 'read' : 'cards'); tab = 'archive'; }
    else if (r === 'likes') { html = vLikes(); tab = 'likes'; }
    else if (r === 'words') { html = vWords(); tab = 'words'; }
    else if (r === 'settings') { html = vSettings(); tab = ''; }
    else html = vMissing();
    view.innerHTML = html;
    $$('.tab').forEach((t) => { if (t.dataset.tab === tab) t.setAttribute('aria-current', 'page'); else t.removeAttribute('aria-current'); });
    if (after) after();
    const y = backNav ? scrollPos[r] || 0 : 0;
    window.scrollTo(0, y); lastY = y; backNav = false;
    updateTopbar();
  }
  function updateTopbar() { const tb = $('.topbar'); if (tb) tb.classList.toggle('scrolled', window.scrollY > 6); }

  // ---------------------------------------------------------------- 동작
  async function tearOff(cat) {
    const today = nowKST().key;
    const page = document.getElementById('card-page');
    Daily.more(cat, today);
    ui.pageIdx[cat] = null;
    if (page && !reduceMotion()) { page.classList.add('tearing'); await wait(430); }
    const pane = document.getElementById('learn-pane'); if (!pane) return;
    pane.innerHTML = learnPane(cat, today);
    applyMarks(pane);
    const np = document.getElementById('card-page');
    if (np && !reduceMotion()) { np.classList.add('dropping'); np.addEventListener('animationend', () => np.classList.remove('dropping'), { once: true }); }
    refreshAlgo();
  }
  function refreshPane() {
    const pane = document.getElementById('learn-pane'); if (!pane) return;
    pane.innerHTML = learnPane(ui.learnTab, nowKST().key);
    applyMarks(pane);
    $$('.seg-btn[data-act="learn-tab"]').forEach((b) => { const on = b.dataset.cat === ui.learnTab; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); });
  }
  function refreshAlgo() { const a = $('.algo'); if (a) { const open = a.open; a.outerHTML = algoHtml(); if (open) $('.algo').open = true; } }
  function applyFs() { document.documentElement.dataset.fs = String(S.settings.fs); }
  function exportData() {
    const blob = new Blob([JSON.stringify({ app: 'tteumtteumi', v: 1, at: new Date().toISOString(), data: S }, null, 1)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `tteumtteumi-backup-${nowKST().key}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    toast(PREVIEW ? '미리보기에서는 파일 저장이 막혀 있어요' : '백업 파일을 저장했어요');
  }
  function importData(file) {
    const fr = new FileReader();
    fr.onload = () => {
      try {
        const j = JSON.parse(fr.result); const d = j && j.data;
        if (!d || !Array.isArray(d.history)) throw new Error('bad');
        S = Object.assign(blank(), d); S.settings = Object.assign(blank().settings, d.settings || {});
        save(); applyFs(); toast('백업을 불러왔어요'); render();
      } catch (e) { toast('이 파일은 틈틈이 백업 파일이 아니에요'); }
    };
    fr.readAsText(file);
  }

  function onClick(e) {
    const term = e.target.closest('.term');
    if (term && !term.closest('.sheet')) {
      const host = term.closest('.readable'); const id = host && host.dataset.doc.slice(2); const a = artById(id);
      const g = a && a.glossary[Number(term.dataset.gi)];
      if (g) { e.preventDefault(); Lookup.open(g.term, { gloss: g, doc: host.dataset.doc }); }
      return;
    }
    const mark = e.target.closest('mark.hl');
    if (mark && !window.getSelection().toString()) {
      const host = mark.closest('.readable'); if (host) {
        const doc = host.dataset.doc; const mk = (S.marks[doc] || []).find((m) => String(m.p) === mark.dataset.p && String(m.s) === mark.dataset.s);
        if (mk) { e.preventDefault(); Lookup.open(mk.t, { doc, mk }); return; }
      }
    }
    const el = e.target.closest('[data-act]'); if (!el) return;
    const act = el.dataset.act; const ds = el.dataset;
    switch (act) {
      case 'go': e.preventDefault(); go(ds.to); break;
      case 'back': e.preventDefault(); back(); break;
      case 'close-sheet': closeSheet(); break;
      case 'toast-action': { const t = document.getElementById('toast'); if (t._action) t._action(); break; }
      case 'wx-retry': Weather.mount(true); break;
      case 'learn-open': ui.learnTab = ds.cat; ui.pageIdx[ds.cat] = null; go('learn'); break;
      case 'learn-tab': ui.learnTab = ds.cat; refreshPane(); break;
      case 'more': tearOff(ds.cat); break;
      case 'page': { const cat = ui.learnTab; const n = Daily.entries(cat, nowKST().key).length; const curI = ui.pageIdx[cat] == null ? n - 1 : ui.pageIdx[cat]; ui.pageIdx[cat] = clamp(curI + Number(ds.dir), 0, n - 1); refreshPane(); break; }
      case 'like-card': {
        const on = likeCard(ds.cat, ds.id);
        $$(`[data-act="like-card"][data-cat="${ds.cat}"][data-id="${cssEsc(ds.id)}"]`).forEach((b) => { b.outerHTML = likeBtn(on, 'like-card', `data-cat="${ds.cat}" data-id="${esc(ds.id)}"`); });
        if (route() === 'likes' || route().startsWith('archive')) setTimeout(() => { const keep = document.getElementById('sheet').hidden; if (keep) render(); }, 0);
        break;
      }
      case 'like-art': {
        const on = likeArt(ds.id);
        $$(`[data-act="like-art"]`).forEach((b) => {
          if (b.classList.contains('like-top')) { b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.innerHTML = icon(on ? 'heart-fill' : 'heart'); }
          else b.outerHTML = likeBtn(on, 'like-art', `data-id="${esc(ds.id)}"`);
        });
        break;
      }
      case 'share-card': { const it = Daily.item(ds.cat, ds.id); const [h, s] = cardHead(ds.cat, it); shareText(h, s); break; }
      case 'share-art': { const a = artById(ds.id); if (a) shareText(a.title, `${a.dek}\n\n· ${a.summary3.join('\n· ')}`); break; }
      case 'open-card': openCardSheet(ds.cat, ds.id, ds.d); break;
      case 'flip': { const box = el.closest('.flip'); const back = box.querySelector('.flip-back'); back.hidden = !back.hidden; el.setAttribute('aria-expanded', String(!back.hidden)); break; }
      case 'rv': {
        const box = el.closest('.flip'); const key = box.dataset.key; const today = nowKST().key;
        const r = S.reviews[key] || {};
        S.reviews[key] = ds.ok === '1' ? { last: today, ok: (r.ok || 0) + 1 } : { last: today, again: addDays(today, 1), miss: (r.miss || 0) + 1 };
        save(); toast(ds.ok === '1' ? '잘했어요! 다음 복습 때 또 만나요' : '내일 다시 보여 드릴게요');
        box.classList.add('done'); setTimeout(() => { const w = document.getElementById('review-wrap'); if (w) w.innerHTML = reviewHtml(today); }, 350);
        break;
      }
      case 'set-zodiac': S.settings.zodiac = Number(ds.z); save(); if (document.getElementById('learn-pane')) refreshPane(); else render(); toast(`${ZODIAC[Number(ds.z)]}띠로 정했어요`); break;
      case 'sub-filter': ui.subFilter[ds.cat] = ds.f; render(); break;
      case 'check-news': checkNews(true); break;
      case 'arch-filter': ui.archFilter = ds.f; render(); break;
      case 'like-filter': ui.likeFilter = ds.f; render(); break;
      case 'lookup': Lookup.open(ds.q, { gloss: findGloss(ds.q, `a:${(route().startsWith('a-') ? route().slice(2) : '')}`) }); break;
      case 'unmark': { HL.remove(ds.doc, { p: ds.p, s: Number(ds.s), l: Number(ds.l), t: ds.t }); closeSheet(); toast('형광펜을 지웠어요'); if (route() === 'words') render(); break; }
      case 'word-open': { const w = S.words[Number(ds.i)]; if (w) Lookup.open(w.t, { doc: w.doc, mk: w.mk }); break; }
      case 'word-del': { const w = S.words[Number(ds.i)]; if (w) { if (w.mk) HL.remove(w.doc, w.mk); else { S.words.splice(Number(ds.i), 1); save(); } render(); toast('단어장에서 지웠어요'); } break; }
      case 'tip-ok': S.settings.tip = 99; save(); el.closest('.tip-box').remove(); break;
      case 'fs': S.settings.fs = (S.settings.fs + 1) % 3; save(); applyFs(); toast(['작은 글씨', '보통 글씨', '큰 글씨'][S.settings.fs]); break;
      case 'set-fs': S.settings.fs = Number(ds.v); save(); applyFs(); render(); break;
      case 'use-geo':
        if (!navigator.geolocation || PREVIEW) { toast('이 화면에서는 위치를 쓸 수 없어요'); break; }
        navigator.geolocation.getCurrentPosition((p) => { S.settings.loc = { name: '현재 위치', lat: Math.round(p.coords.latitude * 1000) / 1000, lon: Math.round(p.coords.longitude * 1000) / 1000 }; save(); toast('현재 위치로 날씨를 보여 드릴게요'); render(); }, () => toast('위치 권한이 없어서 기존 지역을 그대로 쓸게요'), { timeout: 10000, maximumAge: 600000 });
        break;
      case 'demo': { const n = Daily.backfill(7); save(); toast(n ? `지난 7일 기록 ${n}장을 만들었어요` : '이미 지난 7일 기록이 있어요'); render(); break; }
      case 'demo-clear': S.history = S.history.filter((h) => !h.demo); save(); toast('체험용 기록을 지웠어요'); render(); break;
      case 'export': exportData(); break;
      case 'clear-all':
        if (ui.clearArm > Date.now()) { const keep = S.settings; S = blank(); S.settings = keep; ui.clearArm = 0; save(); toast('모든 기록을 지웠어요'); render(); }
        else { ui.clearArm = Date.now() + 4000; el.textContent = '한 번 더 누르면 지워져요'; setTimeout(() => { if (ui.clearArm && ui.clearArm <= Date.now()) { ui.clearArm = 0; if (el.isConnected) el.textContent = '지우기'; } }, 4100); }
        break;
      default: break;
    }
  }
  function onChange(e) {
    const el = e.target; const act = el.dataset && el.dataset.act; if (!act) return;
    if (act === 'toggle-cat') { const k = el.dataset.key; const hide = new Set(S.settings.hide); if (el.checked) hide.delete(k); else hide.add(k); S.settings.hide = [...hide]; save(); }
    else if (act === 'toggle-auto') { S.settings.auto = el.checked; save(); toast(el.checked ? '선택하면 바로 칠하고 찾아 줘요' : '선택한 뒤 버튼을 눌러 칠해요'); }
    else if (act === 'set-loc') { if (el.value !== 'here') { S.settings.loc = LOCS[Number(el.value)]; save(); toast(`${S.settings.loc.name} 날씨로 바꿨어요`); } }
    else if (act === 'set-z') { S.settings.zodiac = el.value === '' ? null : Number(el.value); save(); }
    else if (act === 'import' && el.files && el.files[0]) importData(el.files[0]);
  }
  function onSubmit(e) {
    const f = e.target.closest('[data-form="lookup"]'); if (!f) return;
    e.preventDefault();
    const q = (document.getElementById('lk-q') || {}).value || '';
    if (q.trim()) Lookup.setQuery(q.trim());
  }
  function onKey(e) {
    if (e.key === 'Escape') closeSheet();
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('term')) { e.preventDefault(); e.target.click(); }
  }

  // ---------------------------------------------------------------- 시작
  const TABS = [['home', '홈', 'home'], ['learn', '한 장', 'page'], ['archive', '보관함', 'archive'], ['likes', '좋아요', 'heart'], ['words', '단어장', 'marker']];
  function mountChrome() {
    const nav = document.getElementById('tabbar');
    nav.innerHTML = `<div class="tabbar-in">${TABS.map(([r, l, ic]) => `<a class="tab" href="#${r}" data-tab="${r}"><span class="tab-ico">${icon(ic)}</span><span class="tab-label">${l}</span></a>`).join('')}</div>`;
    document.getElementById('sheet-x').innerHTML = icon('x');
  }
  async function start() {
    load(); keepLoad(); applyFs(); mountChrome(); initSheetDrag(); HL.init();
    document.addEventListener('click', onClick);
    document.addEventListener('change', onChange);
    document.addEventListener('submit', onSubmit);
    document.addEventListener('keydown', onKey);
    document.getElementById('scrim').addEventListener('click', () => closeSheet());
    const chip = document.getElementById('hl-chip');
    const chipGo = (e) => { e.preventDefault(); HL.commit(); };
    chip.addEventListener('mousedown', chipGo);
    chip.addEventListener('touchstart', chipGo, { passive: false });
    let ticking = false;
    window.addEventListener('scroll', () => { if (ticking) return; ticking = true; requestAnimationFrame(() => { lastY = window.scrollY; updateTopbar(); ticking = false; }); }, { passive: true });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState !== 'visible') return;
      if (route() === 'home' && document.getElementById('wx')) Weather.mount();
      if (Date.now() - lastNewsCheck > 30 * 60000) checkNews(false);
    });
    const view = document.getElementById('view');
    try { await loadData(); }
    catch (e) {
      view.innerHTML = emptyBox('refresh', '내용을 불러오지 못했어요', '인터넷 연결을 확인한 뒤 다시 열어 주세요.', '', '') + '<p class="center"><button class="btn-primary" onclick="location.reload()">다시 시도</button></p>';
      return;
    }
    window.addEventListener('hashchange', onHash);
    render();
    if (D.fromCache) setTimeout(() => checkNews(false), 600);
    if ('serviceWorker' in navigator && !PREVIEW && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      const had = !!navigator.serviceWorker.controller;
      navigator.serviceWorker.register('sw.js').catch(() => { /* 오프라인 기능만 빠져요 */ });
      navigator.serviceWorker.addEventListener('controllerchange', () => { if (had) toast('새 버전을 받았어요', { action: '새로고침', onAction: () => location.reload(), ms: 8000 }); });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
